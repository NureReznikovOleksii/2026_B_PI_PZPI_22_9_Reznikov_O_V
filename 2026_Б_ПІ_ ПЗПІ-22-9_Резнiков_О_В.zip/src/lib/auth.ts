import { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import GoogleProvider from 'next-auth/providers/google';
import bcrypt from 'bcryptjs';
import dbConnect from './mongodb';
import User from '../models/User';

export const authOptions: NextAuthOptions = {
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID || 'mock-client-id',
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || 'mock-client-secret',
    }),
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Пароль', type: 'password' },
      },
      async authorize(credentials) {
        await dbConnect();
        if (!credentials?.email || !credentials?.password) {
          throw new Error('Введіть email та пароль');
        }

        const user = await User.findOne({ email: credentials.email });

        if (!user || !user.passwordHash) {
          throw new Error('Користувача не знайдено');
        }

        const isPasswordValid = await bcrypt.compare(credentials.password, user.passwordHash);

        if (!isPasswordValid) {
          throw new Error('Неправильний пароль');
        }

        if (user.status === 'pending' || user.status === 'not allowed') {
          throw new Error('Ваш акаунт ще не підтверджено головним лікарем.');
        }

        if (user.status === 'rejected') {
          throw new Error('Ваша заявка на реєстрацію була відхилена.');
        }

        return {
          id: user._id.toString(),
          email: user.email,
          name: user.name,
          role: user.role,
        };
      },
    }),
  ],
  session: {
    strategy: 'jwt',
  },
  callbacks: {
    async jwt({ token, user, account }) {
      // Якщо вхід через Google і ми маємо об'єкт user (це буває тільки при першому вході)
      if (account?.provider === 'google' && user?.email) {
        try {
          await dbConnect();
          // Шукаємо користувача
          let dbUser = await User.findOne({ email: user.email });
          
          if (!dbUser) {
            // Створюємо, якщо немає
            dbUser = await User.create({
              email: user.email,
              name: user.name || 'Без імені',
              role: 'patient',
              googleId: account.providerAccountId
            });

            const PatientModel = (await import('../models/Patient')).default;
            await PatientModel.create({
              userId: dbUser._id,
              diagnosis: 'Новий пацієнт (з Google)',
            });
          }
          
          // Зберігаємо в токен
          token.id = dbUser._id.toString();
          token.role = dbUser.role;
        } catch (error) {
          console.error("Помилка під час створення Google користувача:", error);
        }
      } else if (user) {
        // Для логіну через пароль
        token.id = user.id;
        token.role = (user as any).role;
      }
      return token;
    },
    async session({ session, token }) {
      if (token) {
        session.user = {
          ...session.user,
          id: token.id as string,
          role: token.role as string,
        };
      }
      return session;
    },
  },
  pages: {
    signIn: '/login', // Ми створимо цю сторінку пізніше
  },
  secret: process.env.NEXTAUTH_SECRET,
};
