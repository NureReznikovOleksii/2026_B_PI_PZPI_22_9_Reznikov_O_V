import User from '@/models/User';
import NotificationModel from '@/models/Notification';

export async function sendNotification(userId: string, message: string) {
  try {
    const user = await User.findById(userId);
    
    if (!user) {
      console.error('Користувача не знайдено для відправки сповіщення');
      return false;
    }

    const { emailNotif, telegramNotif, telegramChatId } = user.preferences;

    // Симуляція відправки Telegram
    if (telegramNotif && telegramChatId) {
      console.log(`[TELEGRAM] Відправка повідомлення до ${telegramChatId}: ${message}`);
      // Тут має бути виклик Telegram Bot API:
      // fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, { ... })
      
      await NotificationModel.create({
        userId,
        message,
        type: 'telegram',
        status: 'sent'
      });
    }

    // Симуляція відправки Email
    if (emailNotif) {
      console.log(`[EMAIL] Відправка листа на ${user.email}: ${message}`);
      // Тут має бути виклик SendGrid / Resend:
      // resend.emails.send({ to: user.email, subject: 'Нагадування', html: message })
      
      await NotificationModel.create({
        userId,
        message,
        type: 'email',
        status: 'sent'
      });
    }

    return true;
  } catch (error) {
    console.error('Помилка відправки сповіщення:', error);
    return false;
  }
}
