"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Activity, Mail, Lock, User, FileText, Briefcase, AlertCircle, CheckCircle } from "lucide-react";
import Link from "next/link";

export default function RegisterPage() {
  const router = useRouter();
  
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "patient",
    position: "",
    region: "",
    hospitalName: "",
  });
  const [certificate, setCertificate] = useState<File | null>(null);
  
  const [regions, setRegions] = useState<string[]>([]);
  const [hospitals, setHospitals] = useState<string[]>([]);
  
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  // Завантаження областей
  useEffect(() => {
    fetch("/api/regions")
      .then((res) => res.json())
      .then((data) => setRegions(data))
      .catch((err) => console.error(err));
  }, []);

  // Завантаження лікарень при зміні області
  useEffect(() => {
    if (formData.region) {
      fetch(`/api/hospitals?region=${encodeURIComponent(formData.region)}`)
        .then((res) => res.json())
        .then((data) => {
          setHospitals(data || []);
          if (!data?.includes(formData.hospitalName)) {
            setFormData((prev) => ({ ...prev, hospitalName: "" }));
          }
        })
        .catch((err) => console.error(err));
    } else {
      setHospitals([]);
      setFormData((prev) => ({ ...prev, hospitalName: "" }));
    }
  }, [formData.region]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setCertificate(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const submitData = new FormData();
      submitData.append("name", formData.name);
      submitData.append("email", formData.email);
      submitData.append("password", formData.password);
      submitData.append("role", formData.role);

      if (formData.role === "doctor") {
        submitData.append("position", formData.position);
        submitData.append("region", formData.region);
        submitData.append("hospitalName", formData.hospitalName);
        if (certificate) {
          submitData.append("certificate", certificate);
        } else {
          setError("Завантажте сертифікат або документ, що підтверджує кваліфікацію.");
          setLoading(false);
          return;
        }
      }

      const res = await fetch("/api/auth/register", {
        method: "POST",
        body: submitData, // Не додаємо Content-Type, fetch зробить це автоматично з boundary
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Сталася помилка під час реєстрації.");
      } else {
        setSuccess(data.message || "Реєстрація успішна!");
        setTimeout(() => {
          router.push("/login");
        }, 3000);
      }
    } catch (err) {
      setError("Не вдалося підключитися до сервера.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[90vh] items-center justify-center py-10">
      <div className="w-full max-w-lg overflow-hidden rounded-2xl bg-white shadow-xl ring-1 ring-slate-100 relative z-10">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 px-8 py-8 text-center text-white">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white/20 backdrop-blur-sm">
            <Activity className="h-7 w-7 text-white" />
          </div>
          <h2 className="mt-4 text-2xl font-bold tracking-tight">Створити акаунт</h2>
          <p className="mt-2 text-blue-100 text-sm">Приєднуйтесь до RehabTracker</p>
        </div>
        
        <div className="px-8 py-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="flex items-center gap-2 rounded-lg bg-red-50 p-4 text-sm text-red-600">
                <AlertCircle className="h-5 w-5 flex-shrink-0" />
                <p>{error}</p>
              </div>
            )}

            {success && (
              <div className="flex items-center gap-2 rounded-lg bg-green-50 p-4 text-sm text-green-700">
                <CheckCircle className="h-5 w-5 flex-shrink-0" />
                <p>{success} Перенаправлення на вхід...</p>
              </div>
            )}
            
            {/* Роль */}
            <div className="space-y-3 pb-2">
              <label className="text-sm font-medium text-slate-700">Я реєструюсь як:</label>
              <div className="flex gap-4">
                <button 
                  type="button"
                  onClick={() => setFormData({...formData, role: 'patient'})}
                  className={`flex-1 flex justify-center items-center gap-2 py-3 px-4 rounded-xl border transition-colors ${formData.role === 'patient' ? 'bg-blue-50 border-blue-500 text-blue-700' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`}
                >
                  Пацієнт
                </button>
                <button 
                  type="button"
                  onClick={() => setFormData({...formData, role: 'doctor'})}
                  className={`flex-1 flex justify-center items-center gap-2 py-3 px-4 rounded-xl border transition-colors ${formData.role === 'doctor' ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`}
                >
                  Лікар
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium text-slate-700">Ім'я та Прізвище</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <User className="h-5 w-5" />
                </div>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="block w-full rounded-lg border border-slate-300 bg-slate-50 py-3 pl-10 pr-3 text-slate-900 focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="Олексій Іванов"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium text-slate-700">Email адреса</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Mail className="h-5 w-5" />
                </div>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="block w-full rounded-lg border border-slate-300 bg-slate-50 py-3 pl-10 pr-3 text-slate-900 focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="name@example.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium text-slate-700">Пароль</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                  <Lock className="h-5 w-5" />
                </div>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="block w-full rounded-lg border border-slate-300 bg-slate-50 py-3 pl-10 pr-3 text-slate-900 focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                  placeholder="••••••••"
                  required
                  minLength={6}
                />
              </div>
            </div>

            {/* Додаткові поля для лікаря */}
            {formData.role === 'doctor' && (
              <div className="pt-2 pb-2 space-y-4 border-t border-slate-100">
                <p className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">Дані для верифікації лікаря</p>
                
                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Ваша посада</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <Briefcase className="h-5 w-5" />
                    </div>
                    <input
                      type="text"
                      value={formData.position}
                      onChange={(e) => setFormData({...formData, position: e.target.value})}
                      className="block w-full rounded-lg border border-slate-300 bg-slate-50 py-3 pl-10 pr-3 text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      placeholder="Хірург-реабілітолог, Голов Врач..."
                      required={formData.role === 'doctor'}
                    />
                  </div>
                  <p className="text-xs text-slate-500 mt-1">Вкажіть "Глав Врач", якщо ви головний лікар.</p>
                </div>

                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Область</label>
                  <select
                    value={formData.region}
                    onChange={(e) => setFormData({...formData, region: e.target.value})}
                    className="block w-full rounded-lg border border-slate-300 bg-slate-50 py-3 px-3 text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    required={formData.role === 'doctor'}
                  >
                    <option value="">-- Виберіть область --</option>
                    {regions.map((reg) => (
                      <option key={reg} value={reg}>{reg}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Медичний заклад</label>
                  <select
                    value={formData.hospitalName}
                    onChange={(e) => setFormData({...formData, hospitalName: e.target.value})}
                    disabled={!formData.region}
                    className="block w-full rounded-lg border border-slate-300 bg-slate-50 py-3 px-3 text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 disabled:opacity-50"
                    required={formData.role === 'doctor'}
                  >
                    <option value="">-- Виберіть заклад --</option>
                    {hospitals.map((hosp) => (
                      <option key={hosp} value={hosp}>{hosp}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-sm font-medium text-slate-700">Сертифікат або Диплом (PDF, JPG, PNG)</label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <FileText className="h-5 w-5" />
                    </div>
                    <input
                      type="file"
                      accept=".pdf,image/*"
                      onChange={handleFileChange}
                      className="block w-full rounded-lg border border-slate-300 bg-slate-50 py-2.5 pl-10 pr-3 text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                      required={formData.role === 'doctor'}
                    />
                  </div>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={`mt-4 flex w-full justify-center rounded-lg py-3 px-4 text-sm font-semibold text-white shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-70 transition-all hover:-translate-y-0.5 ${
                formData.role === 'doctor' 
                ? 'bg-indigo-600 hover:bg-indigo-500 focus:ring-indigo-600' 
                : 'bg-blue-600 hover:bg-blue-500 focus:ring-blue-600'
              }`}
            >
              {loading ? "Обробка даних..." : "Зареєструватися"}
            </button>
          </form>

          <div className="mt-8 text-center text-sm text-slate-600">
            Вже маєте акаунт?{" "}
            <Link href="/login" className="font-semibold text-blue-600 hover:text-blue-500 hover:underline">
              Увійти
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
