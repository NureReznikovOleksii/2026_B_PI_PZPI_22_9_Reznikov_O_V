"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Activity, ClipboardList, AlertCircle, ArrowRight, User, HeartPulse, Target } from "lucide-react";

export default function PatientOnboarding() {
  const router = useRouter();
  
  const [formData, setFormData] = useState({
    age: "",
    gender: "Чоловіча",
    primaryProblem: "",
    initialPainLevel: 5,
    dailyLimitations: "",
    surgeryHistory: "",
    rehabGoals: "",
  });
  
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/patients/onboarding", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          age: Number(formData.age),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Сталася помилка під час збереження анкети.");
        setLoading(false);
      } else {
        router.push("/patient");
        router.refresh();
      }
    } catch (err) {
      setError("Не вдалося підключитися до сервера.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[90vh] py-10 px-4 flex items-center justify-center">
      <div className="w-full max-w-3xl overflow-hidden rounded-2xl bg-white shadow-xl ring-1 ring-slate-100 relative z-10">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-8 py-8 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-white opacity-10"></div>
          <div className="absolute bottom-0 right-16 -mb-8 w-32 h-32 rounded-full bg-white opacity-10"></div>
          
          <div className="relative z-10 flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white/20 backdrop-blur-md border border-white/30">
              <ClipboardList className="h-7 w-7 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Первинне медичне опитування</h2>
              <p className="mt-1 text-blue-100 text-sm max-w-lg">
                Будь ласка, дайте відповідь на кілька питань. Це допоможе лікарю краще зрозуміти ваш стан і призначити правильну програму реабілітації.
              </p>
            </div>
          </div>
        </div>
        
        <div className="px-8 py-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            {error && (
              <div className="flex items-center gap-2 rounded-lg bg-red-50 p-4 text-sm text-red-600 border border-red-100">
                <AlertCircle className="h-5 w-5 flex-shrink-0" />
                <p>{error}</p>
              </div>
            )}
            
            {/* Блок 1: Загальна інформація */}
            <div className="space-y-5">
              <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
                <User className="w-5 h-5 text-indigo-500" /> Загальна інформація
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Вік (повних років) <span className="text-red-500">*</span></label>
                  <input
                    type="number" min="1" max="120"
                    value={formData.age}
                    onChange={(e) => setFormData({...formData, age: e.target.value})}
                    className="block w-full rounded-xl border border-slate-300 bg-slate-50 py-3 px-4 text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    placeholder="Наприклад: 35"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-semibold text-slate-700">Стать <span className="text-red-500">*</span></label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({...formData, gender: e.target.value})}
                    className="block w-full rounded-xl border border-slate-300 bg-slate-50 py-3 px-4 text-slate-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="Чоловіча">Чоловіча</option>
                    <option value="Жіноча">Жіноча</option>
                    <option value="Інше">Інше</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Блок 2: Стан здоров'я */}
            <div className="space-y-5">
              <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
                <HeartPulse className="w-5 h-5 text-rose-500" /> Стан здоров'я
              </h3>
              
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">
                  Яка ваша основна проблема / травма / діагноз? <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.primaryProblem}
                  onChange={(e) => setFormData({...formData, primaryProblem: e.target.value})}
                  className="block w-full rounded-xl border border-slate-300 bg-slate-50 py-3 px-4 text-slate-900 focus:border-rose-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                  placeholder="Наприклад: Біль у попереку, відновлення після інсульту, травма коліна..."
                  required
                />
              </div>

              <div className="space-y-3 bg-rose-50/50 p-5 rounded-2xl border border-rose-100">
                <label className="text-sm font-semibold text-slate-700 flex justify-between items-center">
                  <span>Оцініть ваш поточний середній рівень болю <span className="text-red-500">*</span></span>
                  <span className="font-bold text-lg text-rose-600 bg-white px-3 py-1 rounded-lg border border-rose-200 shadow-sm">{formData.initialPainLevel} / 10</span>
                </label>
                <input 
                  type="range" min="1" max="10" 
                  value={formData.initialPainLevel} 
                  onChange={(e) => setFormData({...formData, initialPainLevel: Number(e.target.value)})}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-rose-500"
                />
                <div className="flex justify-between text-xs font-medium text-slate-500 px-1">
                  <span>1 - Немає болю</span>
                  <span>10 - Нестерпний біль</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Які у вас є обмеження в повсякденному житті через цю проблему?</label>
                <textarea
                  value={formData.dailyLimitations}
                  onChange={(e) => setFormData({...formData, dailyLimitations: e.target.value})}
                  className="block w-full rounded-xl border border-slate-300 bg-slate-50 py-3 px-4 text-slate-900 focus:border-rose-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                  placeholder="Наприклад: Важко підніматися сходами, не можу довго сидіти, важко піднімати руки..."
                  rows={2}
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Чи були у вас операції пов'язані з цією проблемою?</label>
                <textarea
                  value={formData.surgeryHistory}
                  onChange={(e) => setFormData({...formData, surgeryHistory: e.target.value})}
                  className="block w-full rounded-xl border border-slate-300 bg-slate-50 py-3 px-4 text-slate-900 focus:border-rose-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                  placeholder="Якщо так, вкажіть рік та тип операції. Якщо ні - залишіть порожнім."
                  rows={2}
                />
              </div>
            </div>

            {/* Блок 3: Мета */}
            <div className="space-y-5">
              <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-2">
                <Target className="w-5 h-5 text-emerald-500" /> Реабілітація
              </h3>
              
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">
                  Яка ваша головна мета реабілітації? <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={formData.rehabGoals}
                  onChange={(e) => setFormData({...formData, rehabGoals: e.target.value})}
                  className="block w-full rounded-xl border border-slate-300 bg-slate-50 py-3 px-4 text-slate-900 focus:border-emerald-500 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                  placeholder="Наприклад: Повернутися до бігу, ходити без милиць, позбутися болю в спині під час роботи..."
                  rows={3}
                  required
                />
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100">
              <button
                type="submit"
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-4 px-4 text-base font-bold text-white shadow-md hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2 disabled:opacity-70 transition-all hover:-translate-y-0.5"
              >
                {loading ? "Збереження..." : (
                  <>
                    Завершити та перейти в кабінет <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
              <p className="text-center text-xs text-slate-500 mt-4">
                Ця інформація є конфіденційною та буде доступна лише вашому лікарю.
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
