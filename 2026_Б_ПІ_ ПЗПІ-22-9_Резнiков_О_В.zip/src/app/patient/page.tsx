"use client";

import { useState, useEffect } from "react";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { LogOut, CheckCircle, Activity, HeartPulse, Sparkles, User, Calendar, RefreshCw, BarChart2, MapPin, Map, Award, Pill, Target } from "lucide-react";
import PatientChart from "@/components/PatientChart";

export default function PatientDashboard() {
  const { data: session } = useSession();
  const router = useRouter();
  
  // Дані призначень та звітів
  const [assignments, setAssignments] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Вкладки та режими
  const [activeTab, setActiveTab] = useState<'rehab' | 'history' | 'profile'>('rehab');
  const [profileMode, setProfileMode] = useState<'info' | 'doctors'>('info');

  // Дані профілю
  const [patientProfile, setPatientProfile] = useState<any>(null);

  // Дані для вибору в Профілі
  const [regions, setRegions] = useState<string[]>([]);
  const [hospitals, setHospitals] = useState<string[]>([]);
  const [doctors, setDoctors] = useState<any[]>([]);
  
  const [selectedRegion, setSelectedRegion] = useState("");
  const [selectedHospital, setSelectedHospital] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState("");
  
  const [profileMessage, setProfileMessage] = useState("");
  const [profileError, setProfileError] = useState("");
  
  const [pendingDoctor, setPendingDoctor] = useState<any>(null);
  const [doctorRequestStatus, setDoctorRequestStatus] = useState<string>("none");
  const [selectedDoctorInfo, setSelectedDoctorInfo] = useState<any>(null);

  // Зміна лікаря
  const [doctorToChangeTo, setDoctorToChangeTo] = useState<string | null>(null);
  const [changeDoctorFeedback, setChangeDoctorFeedback] = useState("");

  // Форма щоденного звіту
  const [painLevel, setPainLevel] = useState(5);
  const [emotionalState, setEmotionalState] = useState(5);
  const [notes, setNotes] = useState("");
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // ШІ аналітика для пацієнта
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [recommendedSpecialization, setRecommendedSpecialization] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Отримання призначень
  const fetchAssignments = async () => {
    try {
      const res = await fetch("/api/assignments");
      if (res.ok) {
        const data = await res.json();
        setAssignments(data);
      }
    } catch (error) {
      console.error("Помилка завантаження призначень:", error);
    }
  };

  // Отримання логів (звітів)
  const fetchLogs = async () => {
    try {
      const res = await fetch("/api/logs");
      if (res.ok) {
        const data = await res.json();
        setLogs(data);
      }
    } catch (error) {
      console.error("Помилка завантаження логів:", error);
    }
  };

  // Отримання поточного профілю пацієнта
  const fetchPatientProfile = async () => {
    try {
      const res = await fetch("/api/users/me");
      if (res.ok) {
        const data = await res.json();
        const prof = data.profile;
        if (prof) {
          // Якщо пацієнт не пройшов первинне опитування - примусово редиректимо
          if (!prof.hasCompletedOnboarding) {
            router.push('/patient/onboarding');
            return;
          }

          setPatientProfile(prof);
          setSelectedRegion(prof.region || "");
          setSelectedHospital(prof.hospitalName || "");
          setSelectedDoctor(prof.doctorId?._id || prof.doctorId || "");
          setPendingDoctor(prof.pendingDoctorId || null);
          setDoctorRequestStatus(prof.doctorRequestStatus || "none");
        }
      }
    } catch (error) {
      console.error("Помилка завантаження профілю пацієнта:", error);
    }
  };  useEffect(() => {
    const initData = async () => {
      setLoading(true);
      await fetchAssignments();
      await fetchLogs();
      await fetchPatientProfile();

      // Завантажуємо списки регіонів та активних лікарів
      try {
        const regRes = await fetch("/api/regions");
        if (regRes.ok) {
          const regData = await regRes.json();
          setRegions(regData);
        }

        const docRes = await fetch("/api/doctors");
        if (docRes.ok) {
          const docData = await docRes.json();
          setDoctors(docData);
        }
      } catch (error) {
        console.error("Помилка завантаження каталогів лікарів/областей:", error);
      }
      setLoading(false);
    };
    initData();
  }, []);

  // Реактивне завантаження лікарень при зміні області
  useEffect(() => {
    const fetchHospitals = async () => {
      if (!selectedRegion) {
        setHospitals([]);
        return;
      }
      try {
        const res = await fetch(`/api/hospitals?region=${encodeURIComponent(selectedRegion)}`);
        if (res.ok) {
          const data = await res.json();
          setHospitals(data);
        }
      } catch (error) {
        console.error("Помилка завантаження лікарень:", error);
      }
    };
    fetchHospitals();
  }, [selectedRegion]);

  // Збереження профілю (Область, Лікарня, Лікар)
  const handleSaveProfile = async (specificDoctorId?: string) => {
    const finalDoctorId = specificDoctorId || selectedDoctor || null;
    
    // Якщо у пацієнта вже є активний лікар і він обирає нового - відкриваємо модалку зміни
    if (patientProfile?.doctorId && doctorRequestStatus === 'approved') {
      const currentDocId = typeof patientProfile.doctorId === 'object' ? patientProfile.doctorId._id : patientProfile.doctorId;
      if (currentDocId !== finalDoctorId) {
        setDoctorToChangeTo(finalDoctorId);
        return;
      }
    }

    await executeSaveProfile(finalDoctorId);
  };

  const executeSaveProfile = async (finalDoctorId: string | null, feedbackForOldDoctor?: string) => {
    setProfileMessage("");
    setProfileError("");
    setDoctorToChangeTo(null);
    setChangeDoctorFeedback("");
    
    try {
      const res = await fetch('/api/patients', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          region: selectedRegion,
          hospitalName: selectedHospital,
          doctorId: finalDoctorId,
          feedbackForOldDoctor
        })
      });
      if (res.ok) {
        setProfileMessage("Заявку на приписку успішно надіслано лікарю!");
        setTimeout(() => setProfileMessage(""), 3000);
        await fetchPatientProfile();
        fetchAssignments();
      } else {
        const data = await res.json();
        setProfileError(data.error || "Не вдалося надіслати заявку.");
      }
    } catch (error) {
      console.error(error);
      setProfileError("Помилка з'єднання з сервером.");
    }
  };

  // Скасування заявки на приписку
  const handleCancelRequest = async () => {
    setProfileMessage("");
    setProfileError("");
    try {
      const res = await fetch('/api/patients', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cancelRequest: true
        })
      });
      if (res.ok) {
        setProfileMessage("Заявку успішно скасовано!");
        setTimeout(() => setProfileMessage(""), 3000);
        await fetchPatientProfile();
        fetchAssignments();
      } else {
        const data = await res.json();
        setProfileError(data.error || "Не вдалося скасувати заявку.");
      }
    } catch (error) {
      console.error(error);
      setProfileError("Помилка з'єднання з сервером.");
    }
  };

  // Виклик ШІ для підбору лікаря
  const handleAIRecommend = async () => {
    setAiLoading(true);
    setAiAnalysis(null);
    setRecommendedSpecialization(null);
    try {
      const patientData = {
        age: patientProfile?.age,
        gender: patientProfile?.gender,
        diagnosis: patientProfile?.primaryProblem || patientProfile?.diagnosis,
        medicalHistory: patientProfile?.medicalHistory,
        recentLogs: logs.slice(0, 5).map(log => ({
          painLevel: log.painLevel,
          emotionalState: log.emotionalState,
          notes: log.notes,
          date: log.date
        }))
      };

      const res = await fetch('/api/ai/recommend-doctor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ patientData })
      });

      if (res.ok) {
        const data = await res.json();
        setAiAnalysis(data.analysis);
        setRecommendedSpecialization(data.specialization);
      } else {
        const errorData = await res.json();
        setAiAnalysis("Помилка ШІ: " + (errorData.error || "Не вдалося отримати рекомендацію"));
      }
    } catch (error) {
      console.error(error);
      setAiAnalysis("Помилка з'єднання з сервісом ШІ.");
    } finally {
      setAiLoading(false);
    }
  };

  // Збереження щоденного звіту
  const handleSubmitLog = async (assignmentId: string, exercises: any[]) => {
    try {
      const exercisesPayload = exercises.map(ex => ({
        exerciseId: ex.exerciseId._id,
        completedSets: ex.sets,
        completedReps: ex.reps,
        painDuringExercise: painLevel,
      }));

      const res = await fetch("/api/logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assignmentId,
          painLevel,
          emotionalState,
          notes,
          exercises: exercisesPayload,
        }),
      });

      if (res.ok) {
        setSubmitSuccess(true);
        setNotes("");
        fetchLogs(); // Оновити графік та історію в реальному часі
        setTimeout(() => setSubmitSuccess(false), 5000);
      }
    } catch (error) {
      console.error("Помилка збереження звіту:", error);
    }
  };

  // Запит до ШІ для пацієнта
  const handleGenerateAIAnalysis = async () => {
    if (logs.length === 0) return;
    setAiLoading(true);
    setAiAnalysis(null);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ logs, forDoctor: false })
      });
      if (res.ok) {
        const data = await res.json();
        setAiAnalysis(data.analysis);
      } else {
        setAiAnalysis('Не вдалося завантажити аналіз ШІ. Спробуйте пізніше.');
      }
    } catch (error) {
      console.error(error);
      setAiAnalysis('Помилка з\'єднання з сервером ШІ.');
    } finally {
      setAiLoading(false);
    }
  };

  if (loading) return <div className="p-8 text-center text-slate-600 font-medium">Завантаження кабінету пацієнта...</div>;

  return (
    <div className="flex flex-col gap-6 min-h-[80vh]">
      
      {/* Header & Tabs */}
      <div className="bg-white/80 backdrop-blur-md p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
            {session?.user?.name?.charAt(0)}
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">{session?.user?.name}</h2>
            <p className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">Пацієнт</p>
          </div>
        </div>

        {/* Навігація */}
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('rehab')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'rehab' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Реабілітація
          </button>
          
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'history' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Історія звітів
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'profile' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Профіль
          </button>
        </div>

        <button 
          onClick={() => signOut({ callbackUrl: "/login" })} 
          className="flex items-center justify-center gap-2 text-slate-500 hover:text-red-500 transition-colors border border-slate-200 hover:border-red-200 px-4 py-2 rounded-xl text-sm font-semibold bg-white"
        >
          <LogOut className="w-4 h-4" />
          Вийти
        </button>
      </div>

      {/* Вкладка «Реабілітація» */}
      {activeTab === 'rehab' && (
        <div className="space-y-6">
          {submitSuccess && (
            <div className="bg-green-50 border border-green-200 text-green-700 px-6 py-4 rounded-xl flex items-center gap-3 shadow-sm">
              <CheckCircle className="w-6 h-6 flex-shrink-0" />
              <p className="font-semibold text-sm">Ваш щоденний звіт успішно збережено! Ви молодець!</p>
            </div>
          )}

          {assignments.length === 0 ? (
            <div className="bg-white p-12 text-center rounded-2xl border border-slate-100 shadow-sm space-y-4">
              <Activity className="w-16 h-16 text-slate-300 mx-auto" />
              <h3 className="text-xl font-bold text-slate-700">Немає активних призначень</h3>
              <p className="text-sm text-slate-500 max-w-md mx-auto">
                Будь ласка, перейдіть у вкладку <strong>«Профіль»</strong>, виберіть вашу область, медичний заклад і лікаря, щоб лікар міг призначити вам програму реабілітації.
              </p>
            </div>
          ) : (
            assignments.map((assignment) => (
              <div key={assignment._id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="bg-gradient-to-r from-indigo-600 to-blue-600 p-6 text-white shadow-inner">
                  <h3 className="text-xl font-bold">{assignment.programId.title}</h3>
                  <p className="text-indigo-100 mt-1.5 text-sm leading-relaxed">{assignment.programId.description}</p>
                </div>
                
                <div className="p-6 space-y-6">
                  <div>
                    <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-base">
                      <Activity className="w-5 h-5 text-indigo-500" />
                      Вправи на сьогодні
                    </h4>
                    <div className="grid gap-4 md:grid-cols-2">
                      {assignment.exercises.map((ex: any) => (
                        <div key={ex._id} className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                          <p className="font-bold text-slate-800 text-sm">{ex.exerciseId.title}</p>
                          <p className="text-xs text-slate-500 mt-1 leading-relaxed">{ex.exerciseId.description}</p>
                          <div className="mt-3 flex gap-4 text-xs font-bold text-indigo-600">
                            <span>Підходи: {ex.sets}</span>
                            <span>Повторення: {ex.reps}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Медикаментозна підтримка */}
                  {assignment.programId.medications && assignment.programId.medications.length > 0 && (
                    <div className="border-t border-slate-100 pt-6">
                      <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2 text-base">
                        <Pill className="w-5 h-5 text-indigo-550" />
                        Медикаментозна підтримка (препарати)
                      </h4>
                      <div className="grid gap-4 md:grid-cols-2">
                        {assignment.programId.medications.map((med: any, idx: number) => (
                          <div key={idx} className="p-4 bg-indigo-50/40 rounded-xl border border-indigo-100/50 flex items-start gap-3">
                            <div className="p-2 bg-indigo-100/80 rounded-lg text-indigo-650 shrink-0">
                              <Pill className="w-4 h-4" />
                            </div>
                            <div>
                              <p className="font-bold text-indigo-955 text-sm">{med.name}</p>
                              <p className="text-xs text-indigo-800 mt-1"><strong>Дозування:</strong> {med.dosage}</p>
                              <p className="text-xs text-indigo-800"><strong>Частота:</strong> {med.frequency}</p>
                              <p className="text-xs text-indigo-800"><strong>Курс:</strong> {med.duration}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="border-t border-slate-100 pt-6">
                    <h4 className="font-bold text-slate-800 mb-6 flex items-center gap-2 text-base">
                      <HeartPulse className="w-5 h-5 text-rose-500" />
                      Щоденний звіт про стан
                    </h4>
                    
                    <div className="space-y-6 max-w-2xl">
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2.5">
                          Рівень болю (1 - немає болю, 10 - нестерпний біль): <span className="font-bold text-rose-500 text-base">{painLevel}</span>
                        </label>
                        <input 
                          type="range" min="1" max="10" 
                          value={painLevel} onChange={(e) => setPainLevel(Number(e.target.value))}
                          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-rose-500"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2.5">
                          Емоційний стан (1 - пригнічений, 10 - відмінний): <span className="font-bold text-blue-500 text-base">{emotionalState}</span>
                        </label>
                        <input 
                          type="range" min="1" max="10" 
                          value={emotionalState} onChange={(e) => setEmotionalState(Number(e.target.value))}
                          className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-500"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-slate-700 mb-2">Ваші нотатки або скарги (опціонально)</label>
                        <textarea 
                          value={notes} onChange={(e) => setNotes(e.target.value)}
                          className="w-full p-3 bg-white text-slate-900 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm"
                          rows={3} placeholder="Опишіть, як минуло тренування, чи виникали труднощі..."
                        />
                      </div>

                      <button 
                        onClick={() => handleSubmitLog(assignment._id, assignment.exercises)}
                        className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-xl shadow-md transition-colors text-sm"
                      >
                        Зберегти результати за сьогодні
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Вкладка «Історія звітів» */}
      {activeTab === 'history' && (
        <div className="space-y-6">
          
          {/* Блок Ші порад */}
          <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-2xl shadow-sm border border-indigo-100/50 p-6 space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">Поради від асистента ШІ</h3>
                  <p className="text-xs text-slate-500">Персональний аналіз та рекомендації на основі вашого щоденника</p>
                </div>
              </div>
              <button
                onClick={handleGenerateAIAnalysis}
                disabled={aiLoading || logs.length === 0}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
              >
                {aiLoading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Аналіз...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    Отримати рекомендації
                  </>
                )}
              </button>
            </div>

            {logs.length === 0 ? (
              <p className="text-xs text-slate-500 italic">Ви ще не зберегли жодного звіту. Рекомендації стануть доступними після першого звіту.</p>
            ) : aiAnalysis ? (
              <div className="bg-white p-4 rounded-xl border border-indigo-100 text-sm text-slate-700 leading-relaxed shadow-inner max-h-[350px] overflow-y-auto whitespace-pre-line">
                {aiAnalysis}
              </div>
            ) : (
              <p className="text-xs text-slate-500 italic">Натисніть кнопку вище, щоб завантажити персональні ШІ-поради щодо відновлення та полегшення болю.</p>
            )}
          </div>

          {/* Графік прогресу пацієнта */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-indigo-500" />
              Графік динаміки мого стану
            </h3>
            <PatientChart logs={logs} />
          </div>

          {/* Список звітів */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-500" />
              Минулі звіти
            </h3>
            <div className="space-y-4">
              {logs.length === 0 ? (
                <p className="text-slate-500 text-sm italic text-center py-6">Історія порожня. Збережіть свій перший звіт!</p>
              ) : (
                logs.map((log: any) => (
                  <div key={log._id} className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-bold text-slate-750 flex items-center gap-1.5 text-sm text-slate-700">
                        <Calendar className="w-4 h-4 text-slate-400" />
                        {new Date(log.date).toLocaleDateString('uk-UA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                      </span>
                      <div className="flex gap-2 text-xs font-bold">
                        <span className="text-rose-700 bg-rose-50 border border-rose-100 px-2.5 py-1 rounded-full">Біль: {log.painLevel}/10</span>
                        <span className="text-blue-700 bg-blue-50 border border-blue-100 px-2.5 py-1 rounded-full">Настрій: {log.emotionalState}/10</span>
                      </div>
                    </div>
                    {log.notes && <p className="text-slate-650 text-sm mt-3 border-l-2 border-slate-300 pl-3 italic text-slate-600">"{log.notes}"</p>}
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      )}

      {/* Вкладка «Профіль» */}
      {activeTab === 'profile' && (
        <div className="space-y-6 w-full">
          {/* Перемикач режимів */}
          <div className="flex bg-slate-100 p-1 rounded-xl w-fit">
            <button
              onClick={() => setProfileMode('info')}
              className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all ${profileMode === 'info' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Особисті дані
            </button>
            <button
              onClick={() => setProfileMode('doctors')}
              className={`px-6 py-2 rounded-lg text-sm font-semibold transition-all ${profileMode === 'doctors' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
            >
              Медичний заклад та лікар
            </button>
          </div>

          {profileMessage && (
            <div className="bg-green-50 text-green-700 p-3 rounded-xl text-sm font-semibold border border-green-200">
              {profileMessage}
            </div>
          )}

          {profileError && (
            <div className="bg-red-50 text-red-700 p-3 rounded-xl text-sm font-semibold border border-red-200">
              {profileError}
            </div>
          )}

          {/* Режим 1: Особисті дані */}
          {profileMode === 'info' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-6">
              <div className="flex items-center gap-2.5">
                <User className="w-6 h-6 text-indigo-600" />
                <h3 className="text-xl font-bold text-slate-800">Мій профіль</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">ПІБ</p>
                  <p className="font-semibold text-slate-800 mt-1">{session?.user?.name}</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email</p>
                  <p className="font-semibold text-slate-800 mt-1">{session?.user?.email}</p>
                </div>
                {patientProfile?.age && (
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Вік</p>
                    <p className="font-semibold text-slate-800 mt-1">{patientProfile.age} років</p>
                  </div>
                )}
                {patientProfile?.gender && (
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Стать</p>
                    <p className="font-semibold text-slate-800 mt-1">{patientProfile.gender}</p>
                  </div>
                )}
              </div>

              {patientProfile?.primaryProblem && (
                <div className="pt-4 border-t border-slate-100 space-y-4">
                  <h4 className="font-bold text-slate-850 text-sm flex items-center gap-1.5 text-slate-700">
                    <HeartPulse className="w-4 h-4 text-rose-500" />
                    Медичні дані з анкети
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-rose-50/50 rounded-xl border border-rose-100">
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Основна проблема / Діагноз</p>
                      <p className="font-semibold text-slate-800 mt-1">{patientProfile.primaryProblem}</p>
                    </div>
                    <div className="p-4 bg-rose-50/50 rounded-xl border border-rose-100">
                      <p className="text-xs font-bold text-slate-500 uppercase tracking-wider">Рівень болю (до реабілітації)</p>
                      <p className="font-bold text-rose-600 mt-1 text-lg">{patientProfile.initialPainLevel} / 10</p>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 md:col-span-2">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Обмеження в житті</p>
                      <p className="font-medium text-slate-700 mt-1">{patientProfile.dailyLimitations || 'Не вказано'}</p>
                    </div>
                    {patientProfile.surgeryHistory && (
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 md:col-span-2">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Історія операцій</p>
                        <p className="font-medium text-slate-700 mt-1">{patientProfile.surgeryHistory}</p>
                      </div>
                    )}
                    <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100 md:col-span-2">
                      <p className="text-xs font-bold text-emerald-600 uppercase tracking-wider flex items-center gap-1">
                        <Target className="w-3 h-3" /> Мета реабілітації
                      </p>
                      <p className="font-medium text-slate-800 mt-1">{patientProfile.rehabGoals}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Режим 2: Вибір лікаря */}
          {profileMode === 'doctors' && (
            <div className="space-y-6">
              
              {/* Блок ШІ-Підбору лікаря */}
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100 shadow-sm">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
                  <div>
                    <h4 className="font-bold text-indigo-900 text-lg flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-indigo-500" />
                      ШІ-Підбір лікаря
                    </h4>
                    <p className="text-sm text-indigo-700 mt-1">
                      Штучний інтелект проаналізує вашу анкету та щоденні звіти, щоб порадити найкращого спеціаліста.
                    </p>
                  </div>
                  <button
                    onClick={handleAIRecommend}
                    disabled={aiLoading}
                    className="shrink-0 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold rounded-xl transition-all shadow-md shadow-indigo-200 disabled:opacity-70 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {aiLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" /> Аналізуємо...
                      </>
                    ) : "Проаналізувати стан"}
                  </button>
                </div>

                {aiAnalysis && (
                  <div className="bg-white/90 backdrop-blur rounded-2xl p-5 border border-indigo-50 shadow-sm mt-4">
                    <p className="text-slate-800 text-sm leading-relaxed mb-4">{aiAnalysis}</p>
                    
                    {recommendedSpecialization && (
                      <div className="space-y-4 pt-4 border-t border-slate-100">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Рекомендована спеціалізація:</span>
                          <span className="inline-block px-3 py-1 bg-indigo-100 text-indigo-800 font-bold text-sm rounded-lg">
                            {recommendedSpecialization}
                          </span>
                        </div>
                        
                        {doctors.filter(d => d.specialization === recommendedSpecialization).length > 0 ? (
                          <div className="mt-4 space-y-3">
                            <h5 className="text-sm font-bold text-slate-700">Рекомендовані лікарі:</h5>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                              {doctors
                                .filter(d => d.specialization === recommendedSpecialization)
                                .slice(0, 3) // Показуємо максимум 3
                                .map((doc) => {
                                  const isCurrentDoctor = doctorRequestStatus === 'approved' && patientProfile?.doctorId?._id === doc.userId;
                                  const isPendingDoctor = doctorRequestStatus === 'pending' && pendingDoctor?._id === doc.userId;
                                  const isButtonDisabled = doctorRequestStatus === 'pending' || isCurrentDoctor;

                                  return (
                                    <div key={'ai-'+doc.userId} className={`bg-white p-4 rounded-xl shadow-sm border transition-all flex flex-col h-full ${isCurrentDoctor ? 'border-green-400 ring-1 ring-green-400' : 'border-indigo-100'}`}>
                                      <div className="flex items-start gap-3 mb-3">
                                        <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-base shrink-0">
                                          {doc.name.charAt(0)}
                                        </div>
                                        <div>
                                          <h5 className="font-bold text-slate-800 text-sm leading-tight">{doc.name}</h5>
                                          <p className="text-[10px] font-semibold text-slate-500 mt-0.5">{doc.hospitalName}</p>
                                        </div>
                                      </div>
                                      
                                      <div className="mt-auto pt-3 border-t border-slate-50 flex gap-2">
                                        <button
                                          onClick={() => setSelectedDoctorInfo(doc)}
                                          className="px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-600 rounded-lg text-xs font-bold transition-colors"
                                        >
                                          Інфо
                                        </button>
                                        <button
                                          onClick={() => handleSaveProfile(doc.userId)}
                                          disabled={isButtonDisabled}
                                          className={`flex-1 py-2 px-2 rounded-lg text-xs font-bold transition-colors shadow-sm
                                            ${isCurrentDoctor ? 'bg-green-100 text-green-700 cursor-default' 
                                            : isPendingDoctor ? 'bg-amber-100 text-amber-700 cursor-default'
                                            : doctorRequestStatus === 'pending' ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                            : 'bg-indigo-600 hover:bg-indigo-700 text-white'}`}
                                        >
                                          {isCurrentDoctor ? 'Ваш лікар' 
                                            : isPendingDoctor ? 'На розгляді'
                                            : 'Надіслати заявку'}
                                        </button>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                          </div>
                        ) : (
                          <p className="text-sm text-rose-600 bg-rose-50 p-3 rounded-xl border border-rose-100">
                            На жаль, лікарів з такою спеціалізацією наразі немає в системі.
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Основна сітка */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Ліва колонка: Фільтри та статус */}
              <div className="md:col-span-1 space-y-6">
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-5">
                  <h4 className="font-bold text-slate-850 text-sm flex items-center gap-1.5 text-slate-700">
                    <MapPin className="w-4 h-4 text-indigo-500" />
                    Пошук лікаря
                  </h4>
                  
                  {/* Статус приписки */}
                  <div className="rounded-xl border border-slate-200 text-sm space-y-2 bg-slate-50 p-3">
                    <span className="font-bold text-xs uppercase tracking-wider block text-slate-400">Поточний статус</span>
                    {doctorRequestStatus === 'approved' && patientProfile?.doctorId ? (
                      <div className="text-green-700 bg-green-50 border border-green-200 p-2 rounded-lg text-xs">
                        <span className="font-bold block mb-1">Активна приписка!</span>
                        Ваш лікар: {patientProfile.doctorId.name}
                      </div>
                    ) : doctorRequestStatus === 'pending' && pendingDoctor ? (
                      <div className="space-y-2">
                        <div className="text-amber-700 bg-amber-50 border border-amber-200 p-2 rounded-lg text-xs">
                          <span className="font-bold block mb-1">Заявка на розгляді</span>
                          Лікар: {pendingDoctor.name}
                        </div>
                        <button
                          onClick={handleCancelRequest}
                          className="w-full py-1.5 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg border border-slate-200 transition-colors"
                        >
                          Скасувати заявку
                        </button>
                      </div>
                    ) : doctorRequestStatus === 'rejected' ? (
                      <div className="text-rose-700 bg-rose-50 border border-rose-200 p-2 rounded-lg text-xs">
                        <span className="font-bold block mb-1">Заявку відхилено</span>
                        Оберіть іншого лікаря.
                      </div>
                    ) : (
                      <div className="text-slate-500 italic text-xs">
                        Приписка відсутня.
                      </div>
                    )}
                  </div>

                  {/* Область */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Область</label>
                    <select
                      value={selectedRegion}
                      onChange={(e) => {
                        setSelectedRegion(e.target.value);
                        setSelectedHospital("");
                      }}
                      className="w-full p-2.5 bg-white text-slate-900 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm"
                    >
                      <option value="">-- Виберіть область --</option>
                      {regions.map((reg) => (
                        <option key={reg} value={reg}>{reg}</option>
                      ))}
                    </select>
                  </div>

                  {/* Лікарня */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider">Медичний заклад</label>
                    <select
                      value={selectedHospital}
                      onChange={(e) => setSelectedHospital(e.target.value)}
                      disabled={!selectedRegion}
                      className="w-full p-2.5 bg-white text-slate-900 border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none text-sm disabled:bg-slate-50 disabled:text-slate-400"
                    >
                      <option value="">-- Виберіть лікарню --</option>
                      {hospitals.map((hosp) => (
                        <option key={hosp} value={hosp}>{hosp}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Права колонка: Список лікарів */}
              <div className="md:col-span-2">
                {!selectedHospital ? (
                  <div className="h-full min-h-[200px] flex items-center justify-center bg-white rounded-2xl shadow-sm border border-slate-100 p-6 text-center text-slate-500">
                    Оберіть область та медичний заклад зліва, щоб побачити список доступних лікарів.
                  </div>
                ) : (
                  <div className="space-y-4">
                    <h4 className="font-bold text-lg text-slate-800">Лікарі у "{selectedHospital}"</h4>
                    
                    {doctors.filter((doc) => doc.hospitalName === selectedHospital).length === 0 ? (
                      <div className="bg-rose-50 p-6 rounded-2xl border border-rose-100 text-center text-rose-600">
                        На жаль, у цьому закладі ще немає зареєстрованих лікарів.
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {doctors
                          .filter((doc) => doc.hospitalName === selectedHospital)
                          .map((doc) => {
                            const isCurrentDoctor = doctorRequestStatus === 'approved' && patientProfile?.doctorId?._id === doc.userId;
                            const isPendingDoctor = doctorRequestStatus === 'pending' && pendingDoctor?._id === doc.userId;
                            const isButtonDisabled = doctorRequestStatus === 'pending' || isCurrentDoctor;

                            return (
                              <div key={doc.userId} className={`bg-white p-5 rounded-2xl shadow-sm border transition-all flex flex-col h-full ${isCurrentDoctor ? 'border-green-400 ring-1 ring-green-400' : 'border-slate-100 hover:shadow-md hover:border-indigo-200'}`}>
                                <div className="flex items-start gap-3 mb-4">
                                  <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-lg shrink-0">
                                    {doc.name.charAt(0)}
                                  </div>
                                  <div>
                                    <h5 className="font-bold text-slate-800 leading-tight">{doc.name}</h5>
                                    <p className="text-xs font-semibold text-indigo-600 mt-1">{doc.specialization}</p>
                                    {doc.position && <p className="text-xs text-slate-500 mt-0.5">{doc.position}</p>}
                                  </div>
                                </div>
                                
                                <div className="mt-auto pt-4 border-t border-slate-50 flex gap-2">
                                  <button
                                    onClick={() => setSelectedDoctorInfo(doc)}
                                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-bold transition-colors"
                                    title="Детальна інформація"
                                  >
                                    Інфо
                                  </button>
                                  <button
                                    onClick={() => handleSaveProfile(doc.userId)}
                                    disabled={isButtonDisabled}
                                    className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-bold transition-colors shadow-sm
                                      ${isCurrentDoctor ? 'bg-green-100 text-green-700 cursor-default' 
                                      : isPendingDoctor ? 'bg-amber-100 text-amber-700 cursor-default'
                                      : doctorRequestStatus === 'pending' ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                      : 'bg-indigo-600 hover:bg-indigo-700 text-white'}`}
                                  >
                                    {isCurrentDoctor ? 'Ваш лікар' 
                                      : isPendingDoctor ? 'Заявка на розгляді'
                                      : 'Надіслати заявку'}
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                      </div>
                    )}
                  </div>
                )}
              </div>

            </div>
            </div>
          )}
        </div>
      )}

      {/* Модальне вікно з інформацією про лікаря */}
      {selectedDoctorInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm" onClick={() => setSelectedDoctorInfo(null)}>
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl transform transition-all" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-start mb-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-indigo-100 flex items-center justify-center text-indigo-600 font-bold text-2xl shrink-0 shadow-inner">
                  {selectedDoctorInfo.name.charAt(0)}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-800">{selectedDoctorInfo.name}</h3>
                  <p className="text-indigo-600 font-semibold">{selectedDoctorInfo.specialization}</p>
                </div>
              </div>
              <button onClick={() => setSelectedDoctorInfo(null)} className="text-slate-400 hover:text-slate-700 bg-slate-50 hover:bg-slate-100 p-2 rounded-xl transition-colors">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5" /> Посада
                </p>
                <p className="font-medium text-slate-800">{selectedDoctorInfo.position || 'Не вказано'}</p>
              </div>
              
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5" /> Медичний заклад
                </p>
                <p className="font-medium text-slate-800">{selectedDoctorInfo.hospitalName}</p>
              </div>
              
              {selectedDoctorInfo.certificateUrl && (
                <div className="bg-indigo-50/70 rounded-2xl p-5 border border-indigo-100/50 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-bold text-indigo-500 uppercase tracking-wider mb-1">Документи</p>
                    <p className="font-medium text-indigo-900">Сертифікат спеціаліста</p>
                  </div>
                  <a href={selectedDoctorInfo.certificateUrl} target="_blank" rel="noreferrer" className="text-indigo-600 hover:text-indigo-800 px-4 py-2 bg-white rounded-xl text-sm font-bold shadow-sm hover:shadow transition-all border border-indigo-50">
                    Переглянути
                  </a>
                </div>
              )}
              {selectedDoctorInfo.feedbacks && selectedDoctorInfo.feedbacks.length > 0 && (
                <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Відгуки пацієнтів</p>
                  <div className="max-h-40 overflow-y-auto pr-2 space-y-3 scrollbar-thin scrollbar-thumb-slate-200">
                    {[...selectedDoctorInfo.feedbacks].sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map((fb: any, idx: number) => (
                      <div key={idx} className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                        <p className="text-sm text-slate-700 italic">«{fb.text}»</p>
                        <p className="text-xs text-slate-400 mt-2">{new Date(fb.createdAt).toLocaleDateString()}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            <div className="mt-8 pt-6 border-t border-slate-100 flex gap-3">
              <button onClick={() => setSelectedDoctorInfo(null)} className="flex-1 py-3.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors">
                Закрити
              </button>
              {doctorRequestStatus !== 'pending' && (!patientProfile?.doctorId || (typeof patientProfile.doctorId === 'object' ? patientProfile.doctorId._id : patientProfile.doctorId) !== selectedDoctorInfo.userId) && (
                <button
                  onClick={() => {
                    handleSaveProfile(selectedDoctorInfo.userId);
                    setSelectedDoctorInfo(null);
                  }}
                  className="flex-1 py-3.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold transition-all shadow-md shadow-indigo-200 hover:shadow-lg hover:-translate-y-0.5"
                >
                  Надіслати заявку
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Модальне вікно підтвердження зміни лікаря */}
      {doctorToChangeTo && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm" onClick={() => setDoctorToChangeTo(null)}>
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl transform transition-all" onClick={e => e.stopPropagation()}>
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
              </div>
              <h3 className="text-xl font-bold text-slate-800">Зміна лікаря</h3>
              <p className="text-slate-500 mt-2 text-sm">Ви дійсно бажаєте відмовитися від послуг поточного лікаря та надіслати нову заявку?</p>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-semibold text-slate-700 mb-2">Розкажіть, будь ласка, причину або що вам не сподобалось (анонімно):</label>
              <textarea
                value={changeDoctorFeedback}
                onChange={(e) => setChangeDoctorFeedback(e.target.value)}
                placeholder="Лікар не відповідав на повідомлення..."
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 focus:border-rose-500 outline-none text-sm text-slate-900 placeholder-slate-400 resize-none shadow-inner"
                rows={4}
              ></textarea>
            </div>
            
            <div className="flex gap-3">
              <button 
                onClick={() => {
                  setDoctorToChangeTo(null);
                  setChangeDoctorFeedback("");
                }} 
                className="flex-1 py-3 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition-colors"
              >
                Скасувати
              </button>
              <button 
                onClick={() => executeSaveProfile(doctorToChangeTo, changeDoctorFeedback || "Причина не вказана")} 
                className="flex-1 py-3 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold transition-all shadow-md shadow-rose-200"
              >
                Підтвердити
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
