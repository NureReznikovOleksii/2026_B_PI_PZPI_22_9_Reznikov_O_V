import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { NextAuthProvider } from "@/components/Providers";
import SoftAurora from "@/components/SoftAurora";

const inter = Inter({ subsets: ["latin", "cyrillic"] });

export const metadata: Metadata = {
  title: "Медичний вебдодаток для реабілітації",
  description: "Система обліку результатів тренувань пацієнтів та генерації аналітики для лікарів.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="uk" suppressHydrationWarning>
      <body className={`${inter.className} text-slate-900`}>
        <NextAuthProvider>
          <div className="fixed inset-0 -z-10 bg-white">
            <SoftAurora
              speed={0.6}
              scale={1.5}
              brightness={1}
              color1="#ffffff"
              color2="#e100ff"
              noiseFrequency={2.5}
              noiseAmplitude={1}
              bandHeight={0.5}
              bandSpread={1}
              octaveDecay={0.1}
              layerOffset={0}
              colorSpeed={1}
              enableMouseInteraction
              mouseInfluence={0.25}
            />
          </div>
          <div className="min-h-screen flex flex-col">
            <header className="bg-white/80 backdrop-blur-md shadow-sm py-4 sticky top-0 z-10 border-b border-slate-100/50">
              <div className="container mx-auto px-4 flex justify-between items-center">
                <h1 className="text-xl font-bold text-blue-600">RehabTracker</h1>
              </div>
            </header>
            <main className="flex-grow container mx-auto px-4 py-8">
              {children}
            </main>
            <footer className="bg-slate-800 text-slate-300 py-6 text-center text-sm">
              &copy; {new Date().getFullYear()} RehabTracker. Всі права захищено.
            </footer>
          </div>
        </NextAuthProvider>
      </body>
    </html>
  );
}
