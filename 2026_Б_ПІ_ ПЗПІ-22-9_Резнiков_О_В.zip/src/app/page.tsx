import { redirect } from "next/navigation";
import { getServerSession } from "next-auth/next";
import { authOptions } from "@/lib/auth";

export default async function Home() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect("/login");
  }

  if (session.user.role === "doctor") {
    redirect("/doctor");
  } else if (session.user.role === "patient") {
    redirect("/patient");
  } else if (session.user.role === "admin") {
    redirect("/admin");
  } else {
    // Якщо роль невідома
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <h2 className="text-2xl font-bold">Вітаємо, {session.user.name}!</h2>
        <p className="mt-4 text-gray-600">Ваша роль: {session.user.role}</p>
      </div>
    );
  }
}
