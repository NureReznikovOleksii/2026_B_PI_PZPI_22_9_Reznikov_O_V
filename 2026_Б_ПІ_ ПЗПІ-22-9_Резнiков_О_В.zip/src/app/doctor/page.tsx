"use client";

import { useState, useEffect } from "react";
import { useSession, signOut } from "next-auth/react";
import { LogOut, Users, FileText, ChevronRight, Activity, Award, User, RefreshCw, Check, X, ShieldAlert, Sparkles, Calendar, Plus, Search, Trash2, Pill, Save } from "lucide-react";
import PatientChart from "@/components/PatientChart";

export default function DoctorDashboard() {
  const { data: session } = useSession();
  const [patients, setPatients] = useState<any[]>([]);
  const [selectedPatient, setSelectedPatient] = useState<any | null>(null);
  const [patientLogs, setPatientLogs] = useState<any[]>([]);
  const [activeAssignment, setActiveAssignment] = useState<any | null>(null);
  
  // Нові стани для вкладок та профілю
  const [activeTab, setActiveTab] = useState<'patients' | 'requests' | 'profile' | 'constructor'>('patients');
  const [doctorProfile, setDoctorProfile] = useState<any | null>(null);
  const [isChief, setIsChief] = useState(false);
  const [pendingDoctors, setPendingDoctors] = useState<any[]>([]);
  const [pendingPatients, setPendingPatients] = useState<any[]>([]);
  
  // Додаткові стани для редагування та ШІ
  const [newDiagnosis, setNewDiagnosis] = useState("");
  const [isEditingDiagnosis, setIsEditingDiagnosis] = useState(false);
  const [updateMessage, setUpdateMessage] = useState("");
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [loading, setLoading] = useState(true);

  // Конструктор програм та пошук ліків
  const [programs, setPrograms] = useState<any[]>([]);
  const [exercisesList, setExercisesList] = useState<any[]>([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [progTitle, setProgTitle] = useState("");
  const [progDescription, setProgDescription] = useState("");
  const [selectedExercises, setSelectedExercises] = useState<any[]>([]); // Array of { exerciseId: string, title: string, sets: number, reps: number }
  const [selectedMedications, setSelectedMedications] = useState<any[]>([]); // Array of { name: string, dosage: string, frequency: string, duration: string }
  
  // Стан для пошуку таблеток
  const [medSearchQuery, setMedSearchQuery] = useState("");
  const [medSearchResults, setMedSearchResults] = useState<any[]>([]);
  const [customMedMode, setCustomMedMode] = useState(false);
  const [customMedName, setCustomMedName] = useState("");
  
  // Стан для призначення програми
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedProgramId, setSelectedProgramId] = useState("");

  // Отримання профілю лікаря та перевірка чи він Головний лікар
  const fetchDoctorProfile = async () => {
    try {
      const res = await fetch("/api/users/me");
      if (res.ok) {
        const data = await res.json();
        setDoctorProfile(data.profile);
        const position = data.profile?.position || "";
        const chief = position.toLowerCase().includes("глав") || position.toLowerCase().includes("голов");
        setIsChief(!!chief);
      }
    } catch (error) {
      console.error("Помилка завантаження профілю:", error);
    }
  };

  // Отримання списку пацієнтів
  const fetchPatients = async () => {
    try {
      const res = await fetch("/api/patients");
      if (res.ok) {
        const data = await res.json();
        setPatients(data);
      }
    } catch (error) {
      console.error("Помилка завантаження пацієнтів:", error);
    }
  };

  // Отримання списку лікарів для апруву (тільки для Головного лікаря)
  const fetchPendingDoctors = async () => {
    try {
      const res = await fetch("/api/doctors?status=not_allowed");
      if (res.ok) {
        const data = await res.json();
        setPendingDoctors(data);
      }
    } catch (error) {
      console.error("Помилка завантаження заявок лікарів:", error);
    }
  };

  const fetchPendingPatients = async () => {
    try {
      const res = await fetch("/api/patients?status=pending");
      if (res.ok) {
        const data = await res.json();
        setPendingPatients(data);
      }
    } catch (error) {
      console.error("Помилка завантаження заявок пацієнтів:", error);
    }
  };

  const handleApprovePatient = async (patientId: string, approve: boolean) => {
    try {
      const res = await fetch("/api/patients", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patientId,
          action: approve ? "approve" : "reject"
        })
      });
      if (res.ok) {
        setPendingPatients(pendingPatients.filter(p => p._id !== patientId));
        fetchPatients();
      }
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    const initData = async () => {
      setLoading(true);
      await fetchDoctorProfile();
      await fetchPatients();
      await fetchPendingPatients();
      setLoading(false);
    };
    initData();
  }, []);

  // Оновлюємо дані при зміні вкладки на заявки
  useEffect(() => {
    if (activeTab === 'requests') {
      if (isChief) {
        fetchPendingDoctors();
      }
      fetchPendingPatients();
    }
  }, [activeTab, isChief]);

  const handleSelectPatient = async (patient: any) => {
    setSelectedPatient(patient);
    setNewDiagnosis(patient.diagnosis);
    setIsEditingDiagnosis(false);
    setAiAnalysis(null);
    setUpdateMessage("");
    setActiveAssignment(null);
    try {
      // Отримуємо щоденники
      const logsRes = await fetch(`/api/logs?patientId=${patient.userId._id}`);
      if (logsRes.ok) {
        const logsData = await logsRes.json();
        setPatientLogs(logsData);
      }

      // Отримуємо поточне призначення програми та таблеток
      const assignmentRes = await fetch(`/api/assignments?patientId=${patient.userId._id}`);
      if (assignmentRes.ok) {
        const assignmentData = await assignmentRes.json();
        if (assignmentData && assignmentData.length > 0) {
          setActiveAssignment(assignmentData[0]);
        }
      }
    } catch (error) {
      console.error("Помилка отримання даних пацієнта:", error);
    }
  };

  // Оновлення діагнозу
  const handleUpdateDiagnosis = async () => {
    if (!selectedPatient) return;
    try {
      const res = await fetch("/api/patients", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patientId: selectedPatient._id,
          diagnosis: newDiagnosis
        })
      });
      if (res.ok) {
        setSelectedPatient({ ...selectedPatient, diagnosis: newDiagnosis });
        setPatients(patients.map(p => p._id === selectedPatient._id ? { ...p, diagnosis: newDiagnosis } : p));
        setIsEditingDiagnosis(false);
        setUpdateMessage("Діагноз успішно оновлено!");
        setTimeout(() => setUpdateMessage(""), 3000);
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Запит до ШІ
  const handleGenerateAIAnalysis = async () => {
    if (!selectedPatient || patientLogs.length === 0) return;
    setAiLoading(true);
    setAiAnalysis(null);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ logs: patientLogs, forDoctor: true })
      });
      if (res.ok) {
        const data = await res.json();
        setAiAnalysis(data.analysis);
      } else {
        setAiAnalysis('Не вдалося згенерувати аналіз ШІ. Перевірте підключення.');
      }
    } catch (error) {
      console.error(error);
      setAiAnalysis('Помилка з\'єднання з сервером аналітики.');
    } finally {
      setAiLoading(false);
    }
  };

  // Апрув / відхилення лікаря
  const handleApproveDoctor = async (doctorId: string, approve: boolean) => {
    try {
      const res = await fetch('/api/doctors', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          doctorId,
          status: approve ? 'allowed' : 'rejected'
        })
      });
      if (res.ok) {
        setPendingDoctors(pendingDoctors.filter(d => d._id !== doctorId));
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Отримання програм
  const fetchPrograms = async () => {
    try {
      const res = await fetch("/api/programs");
      if (res.ok) {
        const data = await res.json();
        setPrograms(data);
      }
    } catch (error) {
      console.error("Помилка завантаження програм:", error);
    }
  };

  // Отримання списку вправ
  const fetchExercises = async () => {
    try {
      const res = await fetch("/api/exercises");
      if (res.ok) {
        const data = await res.json();
        setExercisesList(data);
      }
    } catch (error) {
      console.error("Помилка завантаження вправ:", error);
    }
  };

  // Завантаження при зміні вкладки
  useEffect(() => {
    if (activeTab === 'constructor') {
      fetchPrograms();
      fetchExercises();
    }
  }, [activeTab]);

  // Дебаунс для пошуку ліків
  useEffect(() => {
    if (medSearchQuery.trim().length > 1) {
      const delayDebounceFn = setTimeout(async () => {
        try {
          const res = await fetch(`/api/medicines?query=${encodeURIComponent(medSearchQuery)}`);
          if (res.ok) {
            const data = await res.json();
            setMedSearchResults(data);
          }
        } catch (error) {
          console.error("Помилка пошуку ліків:", error);
        }
      }, 300);
      return () => clearTimeout(delayDebounceFn);
    } else {
      setMedSearchResults([]);
    }
  }, [medSearchQuery]);

  // Додавання вправи до програми
  const handleAddExercise = (exerciseId: string, title: string) => {
    if (selectedExercises.some(ex => ex.exerciseId === exerciseId)) return;
    setSelectedExercises([...selectedExercises, { exerciseId, title, sets: 3, reps: 10 }]);
  };

  // Видалення вправи
  const handleRemoveExercise = (exerciseId: string) => {
    setSelectedExercises(selectedExercises.filter(ex => ex.exerciseId !== exerciseId));
  };

  // Зміна параметрів вправи
  const handleExerciseParamChange = (exerciseId: string, field: 'sets' | 'reps', value: number) => {
    setSelectedExercises(selectedExercises.map(ex => 
      ex.exerciseId === exerciseId ? { ...ex, [field]: value } : ex
    ));
  };

  // Додавання ліків
  const handleAddMedication = (medName: string, defaultDosage = "1 таблетка") => {
    if (selectedMedications.some(m => m.name.toLowerCase() === medName.toLowerCase())) {
      setMedSearchQuery("");
      setMedSearchResults([]);
      return;
    }
    setSelectedMedications([...selectedMedications, { 
      name: medName, 
      dosage: defaultDosage, 
      frequency: "двічі на день", 
      duration: "7 днів" 
    }]);
    setMedSearchQuery("");
    setMedSearchResults([]);
  };

  // Видалення ліків
  const handleRemoveMedication = (index: number) => {
    setSelectedMedications(selectedMedications.filter((_, i) => i !== index));
  };

  // Зміна параметрів ліків
  const handleMedicationParamChange = (index: number, field: string, value: string) => {
    setSelectedMedications(selectedMedications.map((med, i) => 
      i === index ? { ...med, [field]: value } : med
    ));
  };

  // Збереження нової програми
  const handleCreateProgram = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!progTitle || !progDescription || selectedExercises.length === 0) {
      alert("Будь ласка, введіть назву, опис програми та оберіть хоча б одну вправу.");
      return;
    }

    try {
      const res = await fetch("/api/programs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: progTitle,
          description: progDescription,
          exercises: selectedExercises,
          medications: selectedMedications
        })
      });

      if (res.ok) {
        setProgTitle("");
        setProgDescription("");
        setSelectedExercises([]);
        setSelectedMedications([]);
        setShowCreateForm(false);
        fetchPrograms();
        alert("Програму успішно створено!");
      } else {
        const err = await res.json();
        alert(err.error || "Помилка при створенні програми");
      }
    } catch (error) {
      console.error(error);
      alert("Помилка сервера при створенні програми");
    }
  };

  // Призначення програми пацієнту
  const handleAssignProgram = async () => {
    if (!selectedPatient || !selectedProgramId) return;

    try {
      const res = await fetch("/api/assignments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          patientId: selectedPatient.userId._id,
          programId: selectedProgramId
        })
      });

      if (res.ok) {
        setShowAssignModal(false);
        setSelectedProgramId("");
        
        // Оновлюємо призначення
        const assignmentRes = await fetch(`/api/assignments?patientId=${selectedPatient.userId._id}`);
        if (assignmentRes.ok) {
          const assignmentData = await assignmentRes.json();
          if (assignmentData && assignmentData.length > 0) {
            setActiveAssignment(assignmentData[0]);
          }
        }
        
        setUpdateMessage("Програму успішно призначено пацієнту!");
        setTimeout(() => setUpdateMessage(""), 3000);
      } else {
        alert("Помилка призначення програми");
      }
    } catch (error) {
      console.error(error);
      alert("Помилка з'єднання при призначенні програми");
    }
  };

  if (loading) return <div className="p-8 text-center text-slate-600 font-medium">Завантаження даних кабінету...</div>;

  return (
    <div className="flex flex-col gap-6 min-h-[80vh]">
      
      {/* Header & Tabs */}
      <div className="bg-white/80 backdrop-blur-md p-4 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
            {session?.user?.name?.charAt(0)}
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">{session?.user?.name}</h2>
            <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider">
              {isChief ? "Головний лікар" : "Лікар-реабілітолог"}
            </p>
          </div>
        </div>

        {/* Навігація між вкладками */}
        <div className="flex bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab('patients')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'patients' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Пацієнти
          </button>
          
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all flex items-center gap-1.5 ${activeTab === 'requests' ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Заявки
            {(pendingPatients.length > 0 || (isChief && pendingDoctors.length > 0)) && (
              <span className="bg-indigo-600 text-white text-xs px-2 py-0.5 rounded-full">
                {(isChief ? pendingDoctors.length : 0) + pendingPatients.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('constructor')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'constructor' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Конструктор програм
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === 'profile' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}
          >
            Профіль
          </button>
        </div>

        <button 
          onClick={() => signOut({ callbackUrl: "/login" })} 
          className="flex items-center justify-center gap-2 text-slate-500 hover:text-red-500 transition-colors border border-slate-200 hover:border-red-200 px-4 py-2 rounded-xl text-sm font-semibold bg-white"
        >
          <LogOut className="w-4 h-4" />
          Вийти
        </button>
      </div>

      {/* Контент вкладок */}
      {activeTab === 'patients' && (
        <div className="flex flex-col md:flex-row gap-6">
          {/* Список пацієнтів */}
          <div className="w-full md:w-1/3 flex flex-col gap-4">
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden min-h-[400px]">
              <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                <span className="font-bold text-slate-700 text-sm">Пацієнти у моїй системі</span>
                <span className="bg-blue-100 text-blue-800 text-xs px-2.5 py-0.5 rounded-full font-semibold">{patients.length}</span>
              </div>
              
              {patients.length === 0 ? (
                <div className="p-12 text-center text-slate-400">
                  <Users className="w-12 h-12 mx-auto text-slate-200 mb-2" />
                  <p className="text-sm">Немає закріплених пацієнтів</p>
                  <p className="text-xs text-slate-400 mt-1">Пацієнти мають обрати вас у своєму профілі.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {patients.map(patient => (
                    <button
                      key={patient._id}
                      onClick={() => handleSelectPatient(patient)}
                      className={`w-full text-left p-4 flex items-center justify-between hover:bg-slate-50 transition-colors ${selectedPatient?._id === patient._id ? 'bg-blue-50 border-l-4 border-blue-500' : ''}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold">
                          {patient.userId.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-semibold text-slate-800 text-sm">{patient.userId.name}</p>
                          <p className="text-xs text-slate-500 truncate max-w-[170px]">{patient.diagnosis}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-400" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Деталі обраного пацієнта */}
          <div className="w-full md:w-2/3">
            {!selectedPatient ? (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 h-full min-h-[400px] flex flex-col items-center justify-center p-12 text-center text-slate-500">
                <Users className="w-16 h-16 mb-4 text-slate-200" />
                <h3 className="text-xl font-bold text-slate-700">Оберіть пацієнта</h3>
                <p className="mt-2 text-sm text-slate-400">Оберіть пацієнта зі списку ліворуч для перегляду його прогресу, історії та формування рекомендацій через ШІ.</p>
              </div>
            ) : (
              <div className="space-y-6">
                
                {/* Картка пацієнта з діагнозом */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-4">
                  {updateMessage && (
                    <div className="bg-green-50 text-green-700 p-3 rounded-xl text-sm font-semibold border border-green-200">
                      {updateMessage}
                    </div>
                  )}
                  
                  <div className="flex justify-between items-start">
                    <div>
                      <h2 className="text-2xl font-bold text-slate-800">{selectedPatient.userId.name}</h2>
                      <p className="text-sm text-slate-500 mt-1">Email: {selectedPatient.userId.email}</p>
                    </div>
                    
                    {!isEditingDiagnosis ? (
                      <button 
                        onClick={() => setIsEditingDiagnosis(true)}
                        className="text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors"
                      >
                        Редагувати діагноз
                      </button>
                    ) : (
                      <div className="flex gap-2">
                        <button 
                          onClick={handleUpdateDiagnosis}
                          className="text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded-lg flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" /> Зберегти
                        </button>
                        <button 
                          onClick={() => {
                            setIsEditingDiagnosis(false);
                            setNewDiagnosis(selectedPatient.diagnosis);
                          }}
                          className="text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg flex items-center gap-1"
                        >
                          <X className="w-3.5 h-3.5" /> Скасувати
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Діагноз</p>
                      {isEditingDiagnosis ? (
                        <input
                          type="text"
                          value={newDiagnosis}
                          onChange={(e) => setNewDiagnosis(e.target.value)}
                          className="w-full mt-2 p-2 bg-white text-slate-900 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      ) : (
                        <p className="font-semibold text-slate-800 mt-1 text-sm">{selectedPatient.diagnosis}</p>
                      )}
                    </div>
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Локація пацієнта</p>
                      <p className="font-semibold text-slate-800 mt-1 text-sm">
                        {selectedPatient.region || "Не вказано область"}, {selectedPatient.hospitalName || "не вказано лікарню"}
                      </p>
                    </div>
                  </div>

                  {/* Призначена програма */}
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="space-y-1">
                      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Призначена програма та ліки</p>
                      {activeAssignment ? (
                        <div>
                          <p className="font-bold text-slate-800 text-sm">{activeAssignment.programId?.title}</p>
                          <p className="text-xs text-slate-500 mt-0.5">{activeAssignment.programId?.description}</p>
                          {activeAssignment.programId?.medications && activeAssignment.programId.medications.length > 0 && (
                            <div className="mt-2">
                              <p className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1.5">
                                <Pill className="w-3.5 h-3.5" /> Призначені ліки:
                              </p>
                              <div className="flex flex-wrap gap-1.5 mt-1">
                                {activeAssignment.programId.medications.map((med: any, idx: number) => (
                                  <span key={idx} className="bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs px-2 py-0.5 rounded-lg">
                                    {med.name} ({med.dosage} - {med.frequency}, {med.duration})
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ) : (
                        <p className="text-sm text-slate-500 italic">Не призначено жодної програми</p>
                      )}
                    </div>
                    <button
                      onClick={async () => {
                        await fetchPrograms();
                        setShowAssignModal(true);
                      }}
                      className="w-full md:w-auto text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 hover:border-indigo-300 px-4 py-2 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5"
                    >
                      <Plus className="w-4 h-4" /> Призначити програму
                    </button>
                  </div>
                </div>

                {/* Блок ШІ Консультації */}
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl shadow-sm border border-blue-100/50 p-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-indigo-100 rounded-lg text-indigo-600">
                        <Sparkles className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-slate-800">Клінічний аналіз ШІ</h3>
                        <p className="text-xs text-slate-500">Автоматичний аналіз щоденників пацієнта на базі моделі Gemini</p>
                      </div>
                    </div>
                    <button
                      onClick={handleGenerateAIAnalysis}
                      disabled={aiLoading || patientLogs.length === 0}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-1.5"
                    >
                      {aiLoading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          Аналіз...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-3.5 h-3.5" />
                          Згенерувати звіт
                        </>
                      )}
                    </button>
                  </div>

                  {patientLogs.length === 0 ? (
                    <p className="text-xs text-slate-500 italic">Немає відправлених звітів від пацієнта для проведення аналізу ШІ.</p>
                  ) : aiAnalysis ? (
                    <div className="bg-white p-4 rounded-xl border border-blue-100 text-sm text-slate-700 leading-relaxed shadow-inner max-h-[300px] overflow-y-auto whitespace-pre-line">
                      {aiAnalysis}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 italic">Натисніть кнопку вище, щоб завантажити висновок ШІ про динаміку болю, емоційного стану та нотаток.</p>
                  )}
                </div>

                {/* Графік прогресу */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                  <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-blue-500" /> Аналітика прогресу
                  </h3>
                  <PatientChart logs={patientLogs} />
                </div>

                {/* Останні записи */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
                  <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <FileText className="w-5 h-5 text-blue-500" /> Останні записи щоденника
                  </h3>
                  <div className="space-y-4">
                    {patientLogs.length === 0 ? (
                      <p className="text-slate-500 text-sm italic">Пацієнт ще не залишив жодного щоденного звіту.</p>
                    ) : (
                      patientLogs.slice(0, 5).map((log: any) => (
                        <div key={log._id} className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-bold text-slate-700 flex items-center gap-1.5 text-sm">
                              <Calendar className="w-4 h-4 text-slate-400" />
                              {new Date(log.date).toLocaleDateString('uk-UA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                            </span>
                            <div className="flex gap-2 text-xs font-semibold">
                              <span className="text-rose-700 bg-rose-50 border border-rose-100 px-2.5 py-1 rounded-full">Біль: {log.painLevel}/10</span>
                              <span className="text-blue-700 bg-blue-50 border border-blue-100 px-2.5 py-1 rounded-full">Настрій: {log.emotionalState}/10</span>
                            </div>
                          </div>
                          {log.notes && <p className="text-slate-600 text-sm mt-3 border-l-2 border-slate-300 pl-3 italic">"{log.notes}"</p>}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Вкладка «Заявки» */}
      {activeTab === 'requests' && (
        <div className="space-y-6">
          {isChief && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
              <div className="flex items-center gap-2.5 mb-6">
                <ShieldAlert className="w-6 h-6 text-indigo-600" />
                <div>
                  <h3 className="text-xl font-bold text-slate-800">Заявки лікарів на реєстрацію</h3>
                  <p className="text-sm text-slate-500">Тут ви можете перевірити кваліфікацію та сертифікати нових лікарів і надати їм доступ.</p>
                </div>
              </div>

              {pendingDoctors.length === 0 ? (
                <div className="p-12 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                  <Users className="w-12 h-12 mx-auto text-slate-200 mb-2" />
                  <p className="font-semibold text-sm">Немає нових заявок від лікарів</p>
                  <p className="text-xs text-slate-400 mt-1">Всі зареєстровані лікарі підтверджені.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingDoctors.map((doc) => (
                    <div key={doc._id} className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div className="space-y-2">
                        <h4 className="font-bold text-slate-800 text-base">{doc.name}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1 text-sm text-slate-600">
                          <p><strong>Email:</strong> {doc.email}</p>
                          <p><strong>Лікарня:</strong> {doc.hospitalName}</p>
                          <p><strong>Посада:</strong> {doc.position}</p>
                          <p><strong>Спеціалізація:</strong> {doc.specialization}</p>
                        </div>
                        {doc.certificateUrl && (
                          <p className="text-sm mt-1">
                            <strong>Документ:</strong>{" "}
                            <a 
                              href={doc.certificateUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-indigo-600 hover:text-indigo-700 hover:underline inline-flex items-center gap-1 font-semibold"
                            >
                              <Award className="w-4 h-4" /> Переглянути сертифікат
                            </a>
                          </p>
                        )}
                      </div>
                      
                      <div className="flex gap-2 w-full md:w-auto">
                        <button
                          onClick={() => handleApproveDoctor(doc._id, true)}
                          className="flex-1 md:flex-initial bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-xl text-sm transition-all flex items-center justify-center gap-1.5 shadow-sm"
                        >
                          <Check className="w-4 h-4" /> Підтвердити
                        </button>
                        <button
                          onClick={() => handleApproveDoctor(doc._id, false)}
                          className="flex-1 md:flex-initial bg-red-50 hover:bg-red-100 text-red-700 font-bold px-4 py-2 rounded-xl text-sm transition-all flex items-center justify-center gap-1.5 border border-red-200"
                        >
                          <X className="w-4 h-4" /> Відхилити
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Заявки від пацієнтів */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
            <div className="flex items-center gap-2.5 mb-6">
              <Users className="w-6 h-6 text-blue-600" />
              <div>
                <h3 className="text-xl font-bold text-slate-800">Заявки від пацієнтів на приписку</h3>
                <p className="text-sm text-slate-500">Пацієнти, які хочуть лікуватися у вас. Підтвердіть приписку для початку роботи.</p>
              </div>
            </div>

            {pendingPatients.length === 0 ? (
              <div className="p-12 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl bg-slate-50/50">
                <Users className="w-12 h-12 mx-auto text-slate-200 mb-2" />
                <p className="font-semibold text-sm">Немає нових заявок від пацієнтів</p>
                <p className="text-xs text-slate-400 mt-1">Нові запити з'являться тут, коли пацієнти виберуть вас у своєму профілі.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {pendingPatients.map((pat) => (
                  <div key={pat._id} className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="space-y-2">
                      <h4 className="font-bold text-slate-800 text-base">{pat.userId?.name || "Пацієнт"}</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1 text-sm text-slate-600">
                        <p><strong>Email:</strong> {pat.userId?.email || "Не вказано"}</p>
                        <p><strong>Телефон:</strong> {pat.userId?.phone || "Не вказано"}</p>
                        <p><strong>Область:</strong> {pat.region || "Не вказано"}</p>
                        <p><strong>Лікарня:</strong> {pat.hospitalName || "Не вказано"}</p>
                        <p><strong>Попередній діагноз:</strong> {pat.diagnosis || "Не вказано"}</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-2 w-full md:w-auto">
                      <button
                        onClick={() => handleApprovePatient(pat._id, true)}
                        className="flex-1 md:flex-initial bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-xl text-sm transition-all flex items-center justify-center gap-1.5 shadow-sm"
                      >
                        <Check className="w-4 h-4" /> Прийняти
                      </button>
                      <button
                        onClick={() => handleApprovePatient(pat._id, false)}
                        className="flex-1 md:flex-initial bg-red-50 hover:bg-red-100 text-red-700 font-bold px-4 py-2 rounded-xl text-sm transition-all flex items-center justify-center gap-1.5 border border-red-200"
                      >
                        <X className="w-4 h-4" /> Відхилити
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Вкладка «Профіль» */}
      {activeTab === 'profile' && doctorProfile && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-2xl">
          <div className="flex items-center gap-2.5 mb-6">
            <User className="w-6 h-6 text-blue-600" />
            <h3 className="text-xl font-bold text-slate-800">Мій медичний профіль</h3>
          </div>

          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Ім'я</p>
                <p className="font-semibold text-slate-800 mt-1">{session?.user?.name}</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email</p>
                <p className="font-semibold text-slate-800 mt-1">{session?.user?.email}</p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Посада</p>
                <p className="font-semibold text-slate-800 mt-1">{doctorProfile.position || "Не вказано"}</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Спеціалізація</p>
                <p className="font-semibold text-slate-800 mt-1">{doctorProfile.specialization || "Не вказано"}</p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Лікарня</p>
                <p className="font-semibold text-slate-800 mt-1">{doctorProfile.hospitalName || "Не вказано"}</p>
              </div>
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Статус верифікації</p>
                <span className="mt-1 inline-block bg-green-100 text-green-800 text-xs px-2.5 py-0.5 rounded-full font-bold">
                  Дозволений лікар (Активний)
                </span>
              </div>
            </div>

            {doctorProfile.certificateUrl && (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Мій сертифікат</p>
                <a 
                  href={doctorProfile.certificateUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-indigo-600 hover:text-indigo-700 hover:underline font-semibold inline-flex items-center gap-1 text-sm"
                >
                  <Award className="w-4 h-4" /> Переглянути завантажений диплом/сертифікат
                </a>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Вкладка «Конструктор програм» */}
      {activeTab === 'constructor' && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-xl font-bold text-slate-800">Конструктор програм реабілітації</h3>
              <p className="text-sm text-slate-500">Створюйте шаблони програм фізичної реабілітації та призначайте пацієнтам фармакологічну підтримку.</p>
            </div>
            {!showCreateForm && (
              <button
                onClick={() => {
                  setShowCreateForm(true);
                  setSelectedExercises([]);
                  setSelectedMedications([]);
                  setProgTitle("");
                  setProgDescription("");
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl text-sm transition-all flex items-center gap-1.5 shadow-sm"
              >
                <Plus className="w-4 h-4" /> Створити нову програму
              </button>
            )}
          </div>

          {showCreateForm ? (
            <form onSubmit={handleCreateProgram} className="space-y-6 border-t border-slate-100 pt-6">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Назва програми</label>
                  <input
                    type="text"
                    required
                    value={progTitle}
                    onChange={(e) => setProgTitle(e.target.value)}
                    placeholder="напр., Етап 1: Відновлення після розтягнення зв'язок"
                    className="w-full p-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Опис програми</label>
                  <textarea
                    required
                    value={progDescription}
                    onChange={(e) => setProgDescription(e.target.value)}
                    placeholder="Вкажіть мету програми та загальні рекомендації..."
                    rows={3}
                    className="w-full p-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Розділ 1: Вправи */}
              <div className="space-y-3">
                <h4 className="font-bold text-slate-700 border-b border-slate-100 pb-1.5 flex items-center gap-2 text-base">
                  <Activity className="w-5 h-5 text-blue-500" /> Фізична реабілітація (Вправи)
                </h4>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Список доступних вправ */}
                  <div className="border border-slate-200 rounded-xl p-4 bg-slate-50/50 max-h-[300px] overflow-y-auto">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Оберіть вправи зі списку</p>
                    {exercisesList.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">Немає доступних вправ у базі даних.</p>
                    ) : (
                      <div className="space-y-2">
                        {exercisesList.map((ex) => (
                          <div key={ex._id} className="flex justify-between items-center bg-white p-2.5 rounded-lg border border-slate-100 shadow-sm">
                            <div className="pr-2">
                              <p className="text-sm font-semibold text-slate-800">{ex.title}</p>
                              <p className="text-[11px] text-slate-500">{ex.targetMuscleGroup}</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleAddExercise(ex._id, ex.title)}
                              className="text-xs text-blue-600 hover:text-blue-700 font-semibold bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded-md shrink-0"
                            >
                              Додати
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Додані вправи з налаштуваннями */}
                  <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3 max-h-[300px] overflow-y-auto">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Вибрані вправи ({selectedExercises.length})</p>
                    {selectedExercises.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">Додайте хоча б одну вправу ліворуч...</p>
                    ) : (
                      <div className="space-y-3">
                        {selectedExercises.map((ex) => (
                          <div key={ex.exerciseId} className="bg-slate-50 p-3 rounded-lg border border-slate-100 shadow-sm flex flex-col gap-2">
                            <div className="flex justify-between items-center">
                              <span className="text-xs font-bold text-slate-700">{ex.title}</span>
                              <button
                                type="button"
                                onClick={() => handleRemoveExercise(ex.exerciseId)}
                                className="text-xs text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="text-[10px] text-slate-400 font-bold uppercase">Підходи</label>
                                <input
                                  type="number"
                                  min={1}
                                  max={10}
                                  value={ex.sets}
                                  onChange={(e) => handleExerciseParamChange(ex.exerciseId, 'sets', parseInt(e.target.value) || 3)}
                                  className="w-full mt-0.5 p-1 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                                />
                              </div>
                              <div>
                                <label className="text-[10px] text-slate-400 font-bold uppercase">Повторення</label>
                                <input
                                  type="number"
                                  min={1}
                                  max={50}
                                  value={ex.reps}
                                  onChange={(e) => handleExerciseParamChange(ex.exerciseId, 'reps', parseInt(e.target.value) || 10)}
                                  className="w-full mt-0.5 p-1 text-xs border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Розділ 2: Ліки */}
              <div className="space-y-3">
                <h4 className="font-bold text-slate-700 border-b border-slate-100 pb-1.5 flex items-center gap-2 text-base">
                  <Pill className="w-5 h-5 text-indigo-500" /> Фармакологічна підтримка (Медикаменти)
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Пошук ліків */}
                  <div className="space-y-3 relative">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                      <input
                        type="text"
                        value={medSearchQuery}
                        onChange={(e) => setMedSearchQuery(e.target.value)}
                        placeholder="Пошук ліків (напр. Німесил, Ібупрофен...)"
                        className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      />
                    </div>

                    {/* Результати автокомпліту */}
                    {medSearchResults.length > 0 && (
                      <div className="border border-slate-200 bg-white rounded-xl shadow-lg p-2 space-y-1 max-h-[200px] overflow-y-auto absolute z-20 w-full left-0 top-12">
                        {medSearchResults.map((med, idx) => (
                          <button
                            type="button"
                            key={idx}
                            onClick={() => handleAddMedication(med.name, med.defaultDosage)}
                            className="w-full text-left p-2 hover:bg-slate-50 rounded-lg transition-colors flex flex-col"
                          >
                            <span className="text-xs font-bold text-slate-800">{med.name}</span>
                            <span className="text-[10px] text-slate-400">{med.description}</span>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Додавання власної назви */}
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-250 space-y-2">
                      <p className="text-xs font-semibold text-slate-500">Не знайшли ліки в базі? Додайте назву вручную:</p>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customMedName}
                          onChange={(e) => setCustomMedName(e.target.value)}
                          placeholder="Введіть назву ліків"
                          className="flex-1 p-2 border border-slate-200 rounded-lg text-xs focus:outline-none bg-white"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            if (customMedName.trim()) {
                              handleAddMedication(customMedName.trim());
                              setCustomMedName("");
                            }
                          }}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-2 rounded-lg"
                        >
                          Додати
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Додані ліки з дозуванням */}
                  <div className="border border-slate-200 rounded-xl p-4 bg-white space-y-3 max-h-[300px] overflow-y-auto">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Додані медикаменти ({selectedMedications.length})</p>
                    {selectedMedications.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">Медикаменти не додано...</p>
                    ) : (
                      <div className="space-y-4">
                        {selectedMedications.map((med, idx) => (
                          <div key={idx} className="bg-indigo-50/50 p-3 rounded-lg border border-indigo-100 shadow-sm flex flex-col gap-2">
                            <div className="flex justify-between items-center">
                              <span className="text-xs font-bold text-indigo-850 flex items-center gap-1.5">
                                <Pill className="w-3.5 h-3.5" /> {med.name}
                              </span>
                              <button
                                type="button"
                                onClick={() => handleRemoveMedication(idx)}
                                className="text-xs text-red-500 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                            <div className="grid grid-cols-3 gap-2">
                              <div>
                                <label className="text-[9px] text-slate-400 font-bold uppercase">Дозування</label>
                                <input
                                  type="text"
                                  value={med.dosage}
                                  onChange={(e) => handleMedicationParamChange(idx, 'dosage', e.target.value)}
                                  className="w-full mt-0.5 p-1 text-[11px] border border-slate-200 rounded bg-white focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="text-[9px] text-slate-400 font-bold uppercase">Частота</label>
                                <input
                                  type="text"
                                  value={med.frequency}
                                  onChange={(e) => handleMedicationParamChange(idx, 'frequency', e.target.value)}
                                  className="w-full mt-0.5 p-1 text-[11px] border border-slate-200 rounded bg-white focus:outline-none"
                                />
                              </div>
                              <div>
                                <label className="text-[9px] text-slate-400 font-bold uppercase">Курс</label>
                                <input
                                  type="text"
                                  value={med.duration}
                                  onChange={(e) => handleMedicationParamChange(idx, 'duration', e.target.value)}
                                  className="w-full mt-0.5 p-1 text-[11px] border border-slate-200 rounded bg-white focus:outline-none"
                                />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Кнопки збереження */}
              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-sm transition-all"
                >
                  Скасувати
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-sm transition-all flex items-center gap-1.5 shadow-md"
                >
                  <Save className="w-4 h-4" /> Зберегти шаблон програми
                </button>
              </div>
            </form>
          ) : (
            /* Список програм шаблонів */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {programs.length === 0 ? (
                <div className="col-span-full p-12 text-center text-slate-400 border border-dashed border-slate-200 rounded-xl">
                  <Activity className="w-12 h-12 mx-auto text-slate-200 mb-2" />
                  <p className="font-semibold text-sm">Немає шаблонів програм</p>
                  <p className="text-xs text-slate-400 mt-1">Натисніть кнопку «Створити нову програму», щоб розробити перший шаблон.</p>
                </div>
              ) : (
                programs.map((prog) => (
                  <div key={prog._id} className="bg-slate-50 border border-slate-200 p-5 rounded-2xl flex flex-col justify-between shadow-sm">
                    <div>
                      <h4 className="font-bold text-slate-800 text-base">{prog.title}</h4>
                      <p className="text-xs text-slate-500 mt-1">{prog.description}</p>
                      
                      <div className="mt-4 space-y-2">
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Вправи в програмі ({prog.exercises?.length || 0}):</p>
                        <div className="flex flex-wrap gap-1.5">
                          {prog.exercises?.map((ex: any, idx: number) => (
                            <span key={idx} className="bg-blue-50 border border-blue-100 text-blue-700 text-[11px] px-2 py-0.5 rounded-lg">
                              {ex.exerciseId?.title} ({ex.sets}x{ex.reps})
                            </span>
                          ))}
                        </div>
                      </div>

                      {prog.medications && prog.medications.length > 0 && (
                        <div className="mt-3 space-y-2">
                          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                            <Pill className="w-3.5 h-3.5 text-indigo-500" /> Ліки в програмі ({prog.medications.length}):
                          </p>
                          <div className="flex flex-wrap gap-1.5">
                            {prog.medications.map((med: any, idx: number) => (
                              <span key={idx} className="bg-indigo-50 border border-indigo-100 text-indigo-700 text-[11px] px-2 py-0.5 rounded-lg">
                                {med.name} ({med.dosage} - {med.duration})
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      )}

      {/* Модальне вікно призначення програми */}
      {showAssignModal && selectedPatient && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl border border-slate-100 w-full max-w-lg overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-lg font-bold text-slate-800 font-sans">Призначити програму</h3>
              <button
                onClick={() => setShowAssignModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-4">
              <p className="text-sm text-slate-650">
                Оберіть програму реабілітації для пацієнта <strong>{selectedPatient.userId.name}</strong>.
                Попередня призначена програма буде деактивована.
              </p>
              
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Доступні програми</label>
                {programs.length === 0 ? (
                  <p className="text-sm text-slate-400 italic">Створіть хоча б один шаблон програми у вкладці «Конструктор програм».</p>
                ) : (
                  <select
                    value={selectedProgramId}
                    onChange={(e) => setSelectedProgramId(e.target.value)}
                    className="w-full p-3 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  >
                    <option value="">-- Оберіть програму зі списку --</option>
                    {programs.map((prog) => (
                      <option key={prog._id} value={prog._id}>
                        {prog.title}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>
            
            <div className="p-6 border-t border-slate-100 flex justify-end gap-3 bg-slate-50">
              <button
                onClick={() => setShowAssignModal(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-xl text-sm transition-all"
              >
                Скасувати
              </button>
              <button
                onClick={handleAssignProgram}
                disabled={!selectedProgramId}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold rounded-xl text-sm transition-all shadow-sm"
              >
                Призначити програму
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
