"use client";

import { useState, useEffect } from "react";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Users, FileText, CheckCircle, XCircle, LogOut, Shield, ShieldAlert, Check, Search, Trash2 } from "lucide-react";

export default function AdminDashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [activeTab, setActiveTab] = useState<'patients' | 'doctors' | 'requests'>('patients');
  const [patients, setPatients] = useState<any[]>([]);
  const [doctors, setDoctors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
    } else if (status === "authenticated" && session?.user?.role !== "admin") {
      router.push("/");
    }
  }, [status, session, router]);

  useEffect(() => {
    if (status === "authenticated" && session?.user?.role === "admin") {
      fetchData();
    }
  }, [status, session, activeTab]);

  const fetchData = async () => {
    setLoading(true);
    setError("");
    try {
      if (activeTab === 'patients') {
        const res = await fetch("/api/admin/patients");
        if (res.ok) setPatients(await res.json());
        else setError("Помилка завантаження пацієнтів");
      } else {
        const res = await fetch("/api/admin/doctors");
        if (res.ok) setDoctors(await res.json());
        else setError("Помилка завантаження лікарів");
      }
    } catch (err) {
      setError("Не вдалося підключитися до сервера");
    } finally {
      setLoading(false);
    }
  };

  const handleApproveDoctor = async (userId: string, action: 'approve' | 'reject') => {
    try {
      const res = await fetch("/api/admin/doctors", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, action })
      });
      if (res.ok) {
        fetchData(); // Оновити списки
      } else {
        alert("Помилка при зміні статусу");
      }
    } catch (err) {
      alert("Помилка сервера");
    }
  };

  const handleDeleteAccount = async (userId: string, role: 'patient' | 'doctor') => {
    if (!confirm(`Ви дійсно хочете видалити цей акаунт? Всі пов'язані дані будуть втрачені.`)) return;
    
    try {
      const endpoint = role === 'patient' ? '/api/admin/patients' : '/api/admin/doctors';
      const res = await fetch(endpoint, {
        method: 'DELETE',
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId })
      });
      
      if (res.ok) {
        fetchData();
      } else {
        alert("Помилка при видаленні акаунта");
      }
    } catch (err) {
      alert("Помилка сервера");
    }
  };

  if (status === "loading" || (status === "authenticated" && session?.user?.role !== "admin")) {
    return <div className="p-8 text-center text-slate-600 font-medium">Перевірка прав доступу...</div>;
  }

  const pendingRequests = doctors.filter(d => d.status === 'not allowed' || d.status === 'pending');
  const approvedDoctors = doctors.filter(d => d.status === 'allowed' || d.status === 'active');

  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.email.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const filteredDoctors = approvedDoctors.filter(d => 
    d.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    d.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col gap-6 min-h-[80vh] p-4 md:p-8 max-w-7xl mx-auto w-full">
      
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-md p-4 md:p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center text-purple-600 font-bold">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-800">Панель Адміністратора</h2>
            <p className="text-xs font-semibold text-purple-600 uppercase tracking-wider">{session?.user?.name}</p>
          </div>
        </div>

        <button 
          onClick={() => signOut({ callbackUrl: "/login" })}
          className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-rose-600 bg-rose-50 rounded-xl hover:bg-rose-100 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Вийти
        </button>
      </div>

      {/* Tabs */}
      <div className="flex bg-white shadow-sm p-1 rounded-xl border border-slate-100 w-fit">
        <button
          onClick={() => setActiveTab('patients')}
          className={`px-6 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === 'patients' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
        >
          Всі Пацієнти
        </button>
        <button
          onClick={() => setActiveTab('doctors')}
          className={`px-6 py-2.5 rounded-lg text-sm font-semibold transition-all ${activeTab === 'doctors' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
        >
          Всі Лікарі
        </button>
        <button
          onClick={() => setActiveTab('requests')}
          className={`px-6 py-2.5 rounded-lg text-sm font-semibold transition-all flex items-center gap-2 ${activeTab === 'requests' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
        >
          Заявки 
          {doctors.some(d => d.status === 'not allowed') && <span className="w-2 h-2 rounded-full bg-rose-500"></span>}
        </button>
      </div>
      
      {(activeTab === 'patients' || activeTab === 'doctors') && (
        <div className="relative max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-slate-400" />
          </div>
          <input
            type="text"
            placeholder="Пошук за ім'ям або email..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2.5 border border-slate-200 rounded-xl leading-5 bg-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 sm:text-sm shadow-sm"
          />
        </div>
      )}

      {error && <div className="p-4 bg-red-50 text-red-600 rounded-xl">{error}</div>}

      {/* Content */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 min-h-[400px]">
        {loading ? (
          <div className="text-center text-slate-500 py-10">Завантаження даних...</div>
        ) : (
          <>
            {/* Вкладка: Пацієнти */}
            {activeTab === 'patients' && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 uppercase bg-slate-50">
                    <tr>
                      <th className="px-4 py-3 rounded-tl-xl">Ім'я та Email</th>
                      <th className="px-4 py-3">Локація</th>
                      <th className="px-4 py-3">Діагноз / Проблема</th>
                      <th className="px-4 py-3">Лікуючий лікар</th>
                      <th className="px-4 py-3 rounded-tr-xl text-right">Дії</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPatients.length === 0 ? (
                      <tr><td colSpan={5} className="text-center py-8 text-slate-500">Пацієнтів не знайдено</td></tr>
                    ) : (
                      filteredPatients.map(p => (
                        <tr key={p._id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                          <td className="px-4 py-4">
                            <div className="font-bold text-slate-800">{p.name}</div>
                            <div className="text-slate-500 text-xs">{p.email}</div>
                          </td>
                          <td className="px-4 py-4">
                            <div className="text-slate-700">{p.region}</div>
                            <div className="text-slate-500 text-xs">{p.hospitalName}</div>
                          </td>
                          <td className="px-4 py-4 text-slate-700">{p.diagnosis}</td>
                          <td className="px-4 py-4">
                            <span className={`px-2.5 py-1 rounded-md text-xs font-semibold ${p.doctorName !== 'Не призначено' ? 'bg-blue-50 text-blue-700' : 'bg-slate-100 text-slate-500'}`}>
                              {p.doctorName}
                            </span>
                          </td>
                          <td className="px-4 py-4 text-right">
                            <button
                              onClick={() => handleDeleteAccount(p.userId || p._id, 'patient')}
                              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              title="Видалити пацієнта"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Вкладка: Лікарі */}
            {activeTab === 'doctors' && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 uppercase bg-slate-50">
                    <tr>
                      <th className="px-4 py-3 rounded-tl-xl">Лікар</th>
                      <th className="px-4 py-3">Спеціалізація</th>
                      <th className="px-4 py-3">Локація</th>
                      <th className="px-4 py-3">Статус</th>
                      <th className="px-4 py-3 rounded-tr-xl text-right">Дії</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredDoctors.length === 0 ? (
                      <tr><td colSpan={5} className="text-center py-8 text-slate-500">Лікарів не знайдено</td></tr>
                    ) : (
                      filteredDoctors.map(d => (
                        <tr key={d._id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                          <td className="px-4 py-4">
                            <div className="font-bold text-slate-800">{d.name}</div>
                            <div className="text-slate-500 text-xs">{d.email}</div>
                          </td>
                          <td className="px-4 py-4">
                            <div className="text-slate-700">{d.specialization}</div>
                            <div className="text-slate-500 text-xs">{d.position}</div>
                          </td>
                          <td className="px-4 py-4">
                            <div className="text-slate-700">{d.region}</div>
                            <div className="text-slate-500 text-xs">{d.hospitalName}</div>
                          </td>
                          <td className="px-4 py-4">
                            <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-green-50 text-green-700 flex items-center gap-1 w-fit">
                              <CheckCircle className="w-3 h-3" /> Активний
                            </span>
                          </td>
                          <td className="px-4 py-4 text-right">
                            <button
                              onClick={() => handleDeleteAccount(d.userId || d._id, 'doctor')}
                              className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              title="Видалити лікаря"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}

            {/* Вкладка: Заявки */}
            {activeTab === 'requests' && (
              <div className="space-y-4">
                {pendingRequests.length === 0 ? (
                  <div className="text-center py-12 text-slate-500 flex flex-col items-center gap-3">
                    <CheckCircle className="w-12 h-12 text-green-200" />
                    <p>Немає нових заявок на розгляд</p>
                  </div>
                ) : (
                  pendingRequests.map(req => (
                    <div key={req._id} className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 hover:border-purple-200 transition-colors">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-bold shrink-0">
                          {req.name.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-800 text-lg">{req.name}</h4>
                          <p className="text-sm text-slate-500">{req.email} • {req.position}</p>
                          <div className="mt-2 flex flex-wrap gap-2 text-xs">
                            <span className="px-2 py-1 bg-slate-100 rounded-md text-slate-600">{req.region}</span>
                            <span className="px-2 py-1 bg-slate-100 rounded-md text-slate-600">{req.hospitalName}</span>
                          </div>
                          {req.certificateUrl && (
                            <a href={req.certificateUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 mt-3 text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 px-3 py-1.5 rounded-lg">
                              <FileText className="w-3.5 h-3.5" />
                              Переглянути сертифікат
                            </a>
                          )}
                        </div>
                      </div>
                      <div className="flex gap-2 w-full md:w-auto mt-4 md:mt-0">
                        <button
                          onClick={() => handleApproveDoctor(req.userId, 'reject')}
                          className="flex-1 md:flex-none px-4 py-2.5 bg-rose-50 text-rose-600 hover:bg-rose-100 rounded-xl text-sm font-bold transition-colors flex justify-center items-center gap-1"
                        >
                          <XCircle className="w-4 h-4" /> Відхилити
                        </button>
                        <button
                          onClick={() => handleApproveDoctor(req.userId, 'approve')}
                          className="flex-1 md:flex-none px-4 py-2.5 bg-green-500 text-white hover:bg-green-600 rounded-xl text-sm font-bold transition-colors flex justify-center items-center gap-1 shadow-sm"
                        >
                          <Check className="w-4 h-4" /> Підтвердити
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
