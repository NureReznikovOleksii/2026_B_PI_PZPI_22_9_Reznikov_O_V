import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import Patient from '@/models/Patient';
import User from '@/models/User';
import Doctor from '@/models/Doctor';export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || session.user.role !== 'doctor') {
      return NextResponse.json({ error: 'Доступ заборонено. Тільки для лікарів.' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');

    await dbConnect();

    let query: any = { doctorId: session.user.id };
    if (status === 'pending') {
      query = { pendingDoctorId: session.user.id, doctorRequestStatus: 'pending' };
    }

    const patients = await Patient.find(query)
      .populate({
        path: 'userId',
        model: User,
        select: 'name email phone',
      });

    return NextResponse.json(patients);
  } catch (error) {
    console.error('Помилка отримання пацієнтів:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session) {
      return NextResponse.json({ error: 'Не авторизовано' }, { status: 401 });
    }

    await dbConnect();
    const body = await request.json();

    if (session.user.role === 'patient') {
      const { region, hospitalName, doctorId, cancelRequest, feedbackForOldDoctor } = body;

      let updateData: any = { region, hospitalName };

      // Отримуємо поточного пацієнта, щоб дізнатися старого лікаря, якщо він є
      const currentPatient = await Patient.findOne({ userId: session.user.id });

      if (cancelRequest) {
        updateData.pendingDoctorId = null;
        updateData.doctorRequestStatus = 'none';
      } else if (doctorId !== undefined) {
        if (doctorId === null) {
          updateData.doctorId = null;
          updateData.pendingDoctorId = null;
          updateData.doctorRequestStatus = 'none';
        } else {
          // Якщо пацієнт вже мав лікаря (або відмовляється від поточного)
          if (currentPatient?.doctorId) {
            // Якщо є відгук, зберігаємо його
            if (feedbackForOldDoctor) {
              await Doctor.findOneAndUpdate(
                { userId: currentPatient.doctorId },
                {
                  $push: {
                    feedbacks: {
                      text: feedbackForOldDoctor,
                      createdAt: new Date()
                    }
                  }
                }
              );
            }
            // У будь-якому разі відкріплюємо старого лікаря, оскільки подається нова заявка
            updateData.doctorId = null;
          }
          
          updateData.pendingDoctorId = doctorId;
          updateData.doctorRequestStatus = 'pending';
        }
      }

      const updatedPatient = await Patient.findOneAndUpdate(
        { userId: session.user.id },
        updateData,
        { new: true }
      );

      if (!updatedPatient) {
        return NextResponse.json({ error: 'Профіль пацієнта не знайдено' }, { status: 404 });
      }

      return NextResponse.json({ 
        success: true, 
        message: 'Профіль успішно оновлено!', 
        patient: updatedPatient 
      });
    } else if (session.user.role === 'doctor') {
      const { patientId, diagnosis, medicalHistory, action } = body;

      if (!patientId) {
        return NextResponse.json({ error: 'Вкажіть patientId' }, { status: 400 });
      }

      const patient = await Patient.findById(patientId);
      if (!patient) {
        return NextResponse.json({ error: 'Пацієнта не знайдено' }, { status: 404 });
      }

      if (action === 'approve') {
        patient.doctorId = patient.pendingDoctorId;
        patient.pendingDoctorId = undefined;
        patient.doctorRequestStatus = 'approved';
      } else if (action === 'reject') {
        patient.pendingDoctorId = undefined;
        patient.doctorRequestStatus = 'rejected';
      } else {
        if (diagnosis !== undefined) patient.diagnosis = diagnosis;
        if (medicalHistory !== undefined) patient.medicalHistory = medicalHistory;
      }
      
      await patient.save();

      return NextResponse.json({ 
        success: true, 
        message: 'Дані пацієнта успішно оновлено!', 
        patient 
      });
    }

    return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
  } catch (error) {
    console.error('Помилка оновлення даних пацієнта:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
