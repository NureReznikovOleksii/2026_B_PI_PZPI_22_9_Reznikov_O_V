import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import Patient from '@/models/Patient';

export async function PUT(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user || session.user.role !== 'patient') {
      return NextResponse.json({ error: 'Не авторизовано або недостатньо прав' }, { status: 401 });
    }

    const data = await req.json();
    const { 
      age, 
      gender, 
      primaryProblem, 
      initialPainLevel, 
      dailyLimitations, 
      surgeryHistory, 
      rehabGoals 
    } = data;

    // Валідація обов'язкових полів
    if (!age || !gender || !primaryProblem || !initialPainLevel || !rehabGoals) {
      return NextResponse.json({ error: 'Будь ласка, заповніть всі обов\'язкові поля' }, { status: 400 });
    }

    await dbConnect();

    // Знаходимо профіль пацієнта
    const patient = await Patient.findOne({ userId: session.user.id });

    if (!patient) {
      return NextResponse.json({ error: 'Профіль пацієнта не знайдено' }, { status: 404 });
    }

    // Оновлюємо дані
    patient.age = age;
    patient.gender = gender;
    patient.primaryProblem = primaryProblem;
    patient.initialPainLevel = initialPainLevel;
    patient.dailyLimitations = dailyLimitations || '';
    patient.surgeryHistory = surgeryHistory || '';
    patient.rehabGoals = rehabGoals;
    
    // Встановлюємо прапорець проходження онбордингу
    patient.hasCompletedOnboarding = true;

    await patient.save();

    return NextResponse.json({ success: true, message: 'Анкету успішно збережено' });
  } catch (error) {
    console.error('Помилка збереження анкети:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
