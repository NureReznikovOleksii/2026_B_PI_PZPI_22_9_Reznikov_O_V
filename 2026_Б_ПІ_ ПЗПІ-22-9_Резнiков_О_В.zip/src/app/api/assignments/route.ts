import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import PatientAssignment from '@/models/PatientAssignment';
import Program from '@/models/Program';
import ProgramExercise from '@/models/ProgramExercise';
import Exercise from '@/models/Exercise';

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Не авторизовано' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const patientIdParam = searchParams.get('patientId');

    let targetPatientId = session.user.id;

    if (session.user.role === 'doctor') {
      if (!patientIdParam) {
        return NextResponse.json({ error: 'Параметр patientId є обов’язковими для лікаря' }, { status: 400 });
      }
      targetPatientId = patientIdParam;
    } else if (session.user.role !== 'patient') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    await dbConnect();

    // Знаходимо активні призначення пацієнта
    const assignments = await PatientAssignment.find({ 
      patientId: targetPatientId,
      status: 'active' 
    }).populate({
      path: 'programId',
      model: Program,
      select: 'title description medications'
    });

    // Для кожного призначення знайдемо вправи
    const assignmentsWithExercises = await Promise.all(assignments.map(async (assignment) => {
      const programExercises = await ProgramExercise.find({ programId: assignment.programId })
        .populate({
          path: 'exerciseId',
          model: Exercise,
        });
      
      return {
        ...assignment.toObject(),
        exercises: programExercises
      };
    }));

    return NextResponse.json(assignmentsWithExercises);
  } catch (error) {
    console.error('Помилка отримання призначень:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'doctor') {
      return NextResponse.json({ error: 'Доступ заборонено. Тільки для лікарів.' }, { status: 403 });
    }

    await dbConnect();
    const body = await request.json();
    const { patientId, programId } = body;

    if (!patientId || !programId) {
      return NextResponse.json({ error: 'Параметри patientId та programId є обов’язковими' }, { status: 400 });
    }

    // Деактивуємо попередні активні призначення пацієнта
    await PatientAssignment.updateMany(
      { patientId, status: 'active' },
      { status: 'cancelled' }
    );

    // Створюємо нове призначення
    const newAssignment = await PatientAssignment.create({
      patientId,
      programId,
      assignedBy: session.user.id,
      status: 'active',
      startDate: new Date(),
    });

    return NextResponse.json({ success: true, assignment: newAssignment });
  } catch (error) {
    console.error('Помилка створення призначення:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
