import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import Program from '@/models/Program';
import ProgramExercise from '@/models/ProgramExercise';
import Exercise from '@/models/Exercise';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'doctor') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    await dbConnect();

    const templates = await Program.find({ creatorDoctorId: session.user.id }).sort({ createdAt: -1 });

    const populatedTemplates = await Promise.all(
      templates.map(async (prog) => {
        const progExercises = await ProgramExercise.find({ programId: prog._id }).populate({
          path: 'exerciseId',
          model: Exercise
        });

        return {
          _id: prog._id,
          title: prog.title,
          description: prog.description,
          medications: prog.medications || [],
          exercises: progExercises.map((pe) => ({
            exerciseId: pe.exerciseId,
            sets: pe.sets,
            reps: pe.reps,
            durationSeconds: pe.durationSeconds,
          })),
          createdAt: prog.createdAt,
        };
      })
    );

    return NextResponse.json(populatedTemplates);
  } catch (error) {
    console.error('Помилка отримання програм:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'doctor') {
      return NextResponse.json({ error: 'Доступ заборонено. Тільки для лікарів.' }, { status: 403 });
    }

    await dbConnect();
    const body = await request.json();
    const { title, description, exercises, medications } = body;

    if (!title || !description || !exercises || !Array.isArray(exercises) || exercises.length === 0) {
      return NextResponse.json({ error: 'Заповніть назву, опис та додайте хоча б одну вправу' }, { status: 400 });
    }

    const program = await Program.create({
      title,
      description,
      creatorDoctorId: session.user.id,
      medications: medications || [],
    });

    for (const ex of exercises) {
      await ProgramExercise.create({
        programId: program._id,
        exerciseId: ex.exerciseId,
        sets: Number(ex.sets) || 3,
        reps: Number(ex.reps) || 10,
        durationSeconds: ex.durationSeconds ? Number(ex.durationSeconds) : undefined,
      });
    }

    return NextResponse.json({ success: true, programId: program._id, title: program.title });
  } catch (error) {
    console.error('Помилка створення програми:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
