import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Patient from '@/models/Patient';
import Doctor from '@/models/Doctor';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);

    if (!session || !session.user) {
      return NextResponse.json({ error: 'Не авторизовано' }, { status: 401 });
    }

    await dbConnect();

    const user = await User.findById(session.user.id).select('-passwordHash');

    if (!user) {
      return NextResponse.json({ error: 'Користувача не знайдено' }, { status: 404 });
    }

    let profile = null;

    if (user.role === 'patient') {
      profile = await Patient.findOne({ userId: user._id })
        .populate('doctorId', 'name email')
        .populate('pendingDoctorId', 'name email');
    } else if (user.role === 'doctor') {
      profile = await Doctor.findOne({ userId: user._id });
    }

    return NextResponse.json({ user, profile });
  } catch (error) {
    console.error('Помилка отримання профілю:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
