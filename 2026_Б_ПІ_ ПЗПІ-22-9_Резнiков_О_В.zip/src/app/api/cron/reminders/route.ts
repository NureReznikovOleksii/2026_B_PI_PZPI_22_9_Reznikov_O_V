import { NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import PatientAssignment from '@/models/PatientAssignment';
import DailyLog from '@/models/DailyLog';
import { sendNotification } from '@/lib/notifications';

export async function GET(request: Request) {
  // Перевірка секретного ключа для cron (захист ендпоінту)
  const authHeader = request.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    await dbConnect();

    // Знаходимо всіх пацієнтів з активними програмами
    const activeAssignments = await PatientAssignment.find({ status: 'active' });

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let sentCount = 0;

    for (const assignment of activeAssignments) {
      // Перевіряємо, чи є сьогодні звіт від цього пацієнта
      const logExists = await DailyLog.findOne({
        patientId: assignment.patientId,
        date: { $gte: today }
      });

      if (!logExists) {
        // Відправляємо нагадування
        const message = 'Нагадування: Ви ще не заповнили щоденний звіт про реабілітацію. Будь ласка, зайдіть у кабінет пацієнта.';
        await sendNotification(assignment.patientId.toString(), message);
        sentCount++;
      }
    }

    return NextResponse.json({ message: `Розсилка завершена. Надіслано ${sentCount} нагадувань.` });
  } catch (error) {
    console.error('Помилка cron розсилки:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
