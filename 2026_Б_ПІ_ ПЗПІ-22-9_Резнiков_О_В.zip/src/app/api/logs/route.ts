import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import DailyLog from '@/models/DailyLog';
import LogExercise from '@/models/LogExercise';

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session) {
      return NextResponse.json({ error: 'Не авторизовано' }, { status: 401 });
    }

    await dbConnect();

    // Отримуємо query параметр пацієнта, якщо запит робить лікар
    const { searchParams } = new URL(request.url);
    const patientIdParam = searchParams.get('patientId');

    let targetPatientId = session.user.id;

    if (session.user.role === 'doctor') {
      if (!patientIdParam) {
        return NextResponse.json({ error: 'Вкажіть patientId' }, { status: 400 });
      }
      // Тут можна додати перевірку, чи цей пацієнт належить цьому лікарю
      targetPatientId = patientIdParam;
    }

    const logs = await DailyLog.find({ patientId: targetPatientId })
      .sort({ date: -1 })
      .limit(30);

    return NextResponse.json(logs);
  } catch (error) {
    console.error('Помилка отримання логів:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session || session.user.role !== 'patient') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    await dbConnect();

    const body = await request.json();
    const { assignmentId, painLevel, emotionalState, notes, exercises } = body;

    if (!assignmentId || !painLevel || !emotionalState) {
      return NextResponse.json({ error: 'Недостатньо даних' }, { status: 400 });
    }

    const newLog = await DailyLog.create({
      patientId: session.user.id,
      assignmentId,
      date: new Date(),
      painLevel,
      emotionalState,
      notes,
    });

    if (exercises && Array.isArray(exercises)) {
      const logExercises = exercises.map((ex: any) => ({
        logId: newLog._id,
        exerciseId: ex.exerciseId,
        completedSets: ex.completedSets,
        completedReps: ex.completedReps,
        painDuringExercise: ex.painDuringExercise,
      }));

      await LogExercise.insertMany(logExercises);
    }

    return NextResponse.json({ message: 'Звіт успішно збережено', log: newLog }, { status: 201 });
  } catch (error) {
    console.error('Помилка збереження звіту:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
