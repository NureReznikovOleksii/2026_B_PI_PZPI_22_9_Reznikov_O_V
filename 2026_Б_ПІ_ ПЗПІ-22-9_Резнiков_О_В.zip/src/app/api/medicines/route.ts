import { NextResponse } from 'next/server';

const MEDICINES_DATABASE = [
  // Знеболювальні та протизапальні (НПЗЗ)
  { name: 'Німесил', category: 'Знеболювальні та протизапальні (НПЗЗ)', description: 'Гранули для оральної суспензії 100 мг. Застосовується для лікування гострого болю.', defaultDosage: '1 саше (100 мг) двічі на день' },
  { name: 'Ібупрофен', category: 'Знеболювальні та протизапальні (НПЗЗ)', description: 'Таблетки 200 мг / 400 мг. Має знеболювальну, протизапальну та жарознижувальну дію.', defaultDosage: '1 таблетка (400 мг) 2-3 рази на день' },
  { name: 'Диклофенак', category: 'Знеболювальні та протизапальні (НПЗЗ)', description: 'Таблетки, гель або розчин для ін’єкцій. Виражена протизапальна та знеболювальна дія.', defaultDosage: '1 таблетка (50 мг) 2 рази на день' },
  { name: 'Мелоксикам', category: 'Знеболювальні та протизапальні (НПЗЗ)', description: 'Таблетки 7.5 мг / 15 мг. Ефективний при остеоартрозі та запальних процесах суглобів.', defaultDosage: '1 таблетка (15 мг) 1 раз на день' },
  { name: 'Дексалгін', category: 'Знеболювальні та протизапальні (НПЗЗ)', description: 'Таблетки 25 мг. Використовується для симптоматичного лікування гострого болю.', defaultDosage: '1 таблетка (25 мг) кожні 8 годин' },
  { name: 'Кетонал', category: 'Знеболювальні та протизапальні (НПЗЗ)', description: 'Капсули 50 мг / форте 150 мг. Потужний протибольовий ефект.', defaultDosage: '1 капсула (50 мг) 2-3 рази на день' },

  // Міорелаксанти
  { name: 'Мідокалм', category: 'Міорелаксанти', description: 'Таблетки 150 мг. Знижує патологічно підвищений тонус скелетних м’язів, покращує рухливість.', defaultDosage: '1 таблетка (150 мг) 2-3 рази на день' },
  { name: 'Сірдалуд', category: 'Міорелаксанти', description: 'Таблетки 2 мг / 4 мг. Полегшує спазми м’язів та підвищений м’язовий тонус.', defaultDosage: '1 таблетка (2 мг) 3 рази на день' },
  { name: 'Мускомед', category: 'Міорелаксанти', description: 'Капсули 4 мг / 8 мг. Застосовується для симптоматичного лікування болючих м’язових спазмів.', defaultDosage: '1 капсула (4 мг) двічі на день' },

  // Хондропротектори
  { name: 'Терафлекс', category: 'Хондропротектори', description: 'Капсули. Стимулює регенерацію хрящової тканини суглобів, зменшує біль.', defaultDosage: '1 капсула 3 рази на день' },
  { name: 'Дона (Глюкозамін)', category: 'Хондропротектори', description: 'Саше або розчин для ін’єкцій. Відновлює дефіцит глюкозаміну, нормалізує синтез хряща.', defaultDosage: '1 саше 1 раз на день' },
  { name: 'Артрон Комплекс', category: 'Хондропротектори', description: 'Таблетки. Хондроїтин + глюкозамін для зміцнення суглобів.', defaultDosage: '1 таблетка двічі на день' },

  // Вітаміни та біодобавки
  { name: 'Нейрорубін', category: 'Вітаміни групи B', description: 'Таблетки або ампули. Комплекс вітамінів B1, B6, B12 для нервової системи та зняття невритів.', defaultDosage: '1 таблетка 1 раз на день' },
  { name: 'Мільгамма', category: 'Вітаміни групи B', description: 'Драже. Покращує кровопостачання та роботу нервової системи при рухових порушеннях.', defaultDosage: '1 драже 3 рази на день' },
  { name: 'Кальцій-Д3 Нікомед', category: 'Кальцій та Вітамін D3', description: 'Жувальні таблетки. Регулює обмін кальцію та фосфору, зміцнює кістки після переломів.', defaultDosage: '1 таблетка двічі на день' },
  { name: 'Детримакс', category: 'Вітамін D3', description: 'Капсули 1000 МО / 2000 МО / 4000 МО. Підвищує імунітет та сприяє відновленню кісток.', defaultDosage: '1 капсула (2000 МО) 1 раз на день вранці' }
];

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('query');

    if (!query) {
      return NextResponse.json(MEDICINES_DATABASE);
    }

    const normalizedQuery = query.toLowerCase().trim();
    const filtered = MEDICINES_DATABASE.filter(med => 
      med.name.toLowerCase().includes(normalizedQuery) ||
      med.category.toLowerCase().includes(normalizedQuery) ||
      med.description.toLowerCase().includes(normalizedQuery)
    );

    return NextResponse.json(filtered);
  } catch (error) {
    console.error('Помилка отримання медикаментів:', error);
    return NextResponse.json({ error: 'Помилка сервера' }, { status: 500 });
  }
}
