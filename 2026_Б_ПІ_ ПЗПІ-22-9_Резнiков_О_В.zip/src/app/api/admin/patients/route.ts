import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import Patient from '@/models/Patient';
import User from '@/models/User';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    await dbConnect();

    // Отримуємо всіх пацієнтів разом з інформацією про користувача і лікаря
    const patients = await Patient.find({})
      .populate({
        path: 'userId',
        model: User,
        select: 'name email phone status'
      })
      .populate({
        path: 'doctorId',
        model: User,
        select: 'name'
      });

    // Форматуємо результат для зручності на фронтенді
    const formattedPatients = patients.map(p => {
      const user = p.userId as any;
      const doctor = p.doctorId as any;
      return {
        _id: p._id,
        name: user?.name || 'Невідомо',
        email: user?.email || 'Невідомо',
        region: p.region || 'Не вказано',
        hospitalName: p.hospitalName || 'Не вказано',
        diagnosis: p.primaryProblem || p.diagnosis || 'Не вказано',
        doctorName: doctor?.name || 'Не призначено',
        createdAt: p.createdAt
      };
    });

    return NextResponse.json(formattedPatients);
  } catch (error) {
    console.error('Помилка завантаження пацієнтів для адміна:', error);
    return NextResponse.json({ error: 'Помилка сервера' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    const { userId } = await request.json();
    if (!userId) {
      return NextResponse.json({ error: 'Відсутній ID користувача' }, { status: 400 });
    }

    await dbConnect();

    // Видаляємо користувача
    const deletedUser = await User.findByIdAndDelete(userId);
    if (!deletedUser) {
      return NextResponse.json({ error: 'Користувача не знайдено' }, { status: 404 });
    }

    // Видаляємо профіль пацієнта
    await Patient.findOneAndDelete({ userId: userId });

    return NextResponse.json({ success: true, message: 'Пацієнта успішно видалено' });
  } catch (error) {
    console.error('Помилка видалення пацієнта:', error);
    return NextResponse.json({ error: 'Помилка сервера' }, { status: 500 });
  }
}
