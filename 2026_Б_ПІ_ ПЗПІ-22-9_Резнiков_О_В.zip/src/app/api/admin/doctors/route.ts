import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import Doctor from '@/models/Doctor';
import User from '@/models/User';

export async function GET() {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    await dbConnect();

    const doctors = await Doctor.find({})
      .populate({
        path: 'userId',
        model: User,
        select: 'name email status createdAt'
      });

    const formattedDoctors = doctors.map(d => {
      const user = d.userId as any;
      return {
        _id: d._id,
        userId: user?._id,
        name: user?.name || 'Невідомо',
        email: user?.email || 'Невідомо',
        status: user?.status || 'unknown',
        specialization: d.specialization || 'Не вказано',
        position: d.position || 'Не вказано',
        region: d.region || 'Не вказано',
        hospitalName: d.hospitalName || 'Не вказано',
        certificateUrl: d.certificateUrl,
        createdAt: user?.createdAt
      };
    });

    return NextResponse.json(formattedDoctors);
  } catch (error) {
    console.error('Помилка завантаження лікарів для адміна:', error);
    return NextResponse.json({ error: 'Помилка сервера' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    const { userId, action } = await request.json();
    if (!userId || !action) {
      return NextResponse.json({ error: 'Відсутні необхідні параметри' }, { status: 400 });
    }

    await dbConnect();

    const user = await User.findById(userId);
    if (!user || user.role !== 'doctor') {
      return NextResponse.json({ error: 'Лікаря не знайдено' }, { status: 404 });
    }

    if (action === 'approve') {
      user.status = 'allowed';
    } else if (action === 'reject') {
      user.status = 'rejected';
    } else {
      return NextResponse.json({ error: 'Невідома дія' }, { status: 400 });
    }

    await user.save();

    return NextResponse.json({ success: true, message: `Статус змінено на ${user.status}` });
  } catch (error) {
    console.error('Помилка оновлення статусу лікаря:', error);
    return NextResponse.json({ error: 'Помилка сервера' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'admin') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    const { userId } = await request.json();
    if (!userId) {
      return NextResponse.json({ error: 'Відсутній ID користувача' }, { status: 400 });
    }

    await dbConnect();

    // Видаляємо користувача
    const deletedUser = await User.findByIdAndDelete(userId);
    if (!deletedUser) {
      return NextResponse.json({ error: 'Користувача не знайдено' }, { status: 404 });
    }

    // Видаляємо профіль лікаря
    await Doctor.findOneAndDelete({ userId: userId });
    
    // Очищаємо зв'язок у пацієнтів, які були прикріплені до цього лікаря
    const Patient = (await import('@/models/Patient')).default;
    await Patient.updateMany(
      { doctorId: userId }, 
      { $unset: { doctorId: "" }, doctorRequestStatus: 'none' }
    );

    return NextResponse.json({ success: true, message: 'Лікаря успішно видалено' });
  } catch (error) {
    console.error('Помилка видалення лікаря:', error);
    return NextResponse.json({ error: 'Помилка сервера' }, { status: 500 });
  }
}
