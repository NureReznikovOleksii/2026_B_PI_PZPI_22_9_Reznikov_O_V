import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Doctor from '@/models/Doctor';

export async function GET(request: Request) {
  try {
    await dbConnect();
    const session = await getServerSession(authOptions);

    const { searchParams } = new URL(request.url);
    const statusParam = searchParams.get('status');

    if (statusParam === 'not_allowed') {
      if (!session || session.user.role !== 'doctor') {
        return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
      }

      const chiefDoctorProfile = await Doctor.findOne({ userId: session.user.id });
      const isChief = chiefDoctorProfile?.position && (
        chiefDoctorProfile.position.toLowerCase().includes('глав') ||
        chiefDoctorProfile.position.toLowerCase().includes('голов')
      );

      if (!isChief) {
        return NextResponse.json({ error: 'Тільки головний лікар може переглядати заявки' }, { status: 403 });
      }

      const pendingUsers = await User.find({
        role: 'doctor',
        status: { $in: ['not allowed', 'pending'] }
      }).select('name email status createdAt');

      const pendingDoctors = await Promise.all(pendingUsers.map(async (user) => {
        const profile = await Doctor.findOne({ userId: user._id });
        return {
          _id: user._id,
          name: user.name,
          email: user.email,
          status: user.status,
          createdAt: user.createdAt,
          position: profile?.position || 'Не вказано',
          specialization: profile?.specialization || 'Не вказано',
          certificateUrl: profile?.certificateUrl || null,
          hospitalName: profile?.hospitalName || 'Не вказано',
        };
      }));

      return NextResponse.json(pendingDoctors);
    }

    const activeUsers = await User.find({
      role: 'doctor',
      status: { $in: ['allowed', 'active'] }
    }).select('name email');

    const activeDoctors = await Promise.all(activeUsers.map(async (user) => {
      const profile = await Doctor.findOne({ userId: user._id });
      return {
        userId: user._id,
        name: user.name,
        email: user.email,
        position: profile?.position || 'Не вказано',
        specialization: profile?.specialization || 'Не вказано',
        hospitalName: profile?.hospitalName || 'Не вказано',
        feedbacks: profile?.feedbacks || [],
      };
    }));

    return NextResponse.json(activeDoctors);
  } catch (error) {
    console.error('Помилка отримання лікарів:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    await dbConnect();
    const session = await getServerSession(authOptions);

    if (!session || session.user.role !== 'doctor') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    const chiefDoctorProfile = await Doctor.findOne({ userId: session.user.id });
    const isChief = chiefDoctorProfile?.position && (
      chiefDoctorProfile.position.toLowerCase().includes('глав') ||
      chiefDoctorProfile.position.toLowerCase().includes('голов')
    );

    if (!isChief) {
      return NextResponse.json({ error: 'Тільки головний лікар може підтверджувати заявки' }, { status: 403 });
    }

    const body = await request.json();
    const { doctorId, status } = body;

    if (!doctorId || !status) {
      return NextResponse.json({ error: 'Недостатньо даних' }, { status: 400 });
    }

    if (!['allowed', 'rejected', 'not allowed'].includes(status)) {
      return NextResponse.json({ error: 'Недопустимий статус' }, { status: 400 });
    }

    const updatedUser = await User.findByIdAndUpdate(
      doctorId,
      { status },
      { new: true }
    );

    if (!updatedUser) {
      return NextResponse.json({ error: 'Лікаря не знайдено' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: status === 'allowed' ? 'Лікаря успішно підтверджено!' : 'Заявку лікаря відхилено.'
    });
  } catch (error) {
    console.error('Помилка оновлення статусу лікаря:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
