import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import Doctor from '@/models/Doctor';

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'patient') {
      return NextResponse.json({ error: 'Доступ заборонено' }, { status: 403 });
    }

    const { patientData } = await request.json();
    if (!patientData) {
      return NextResponse.json({ error: 'Немає даних для аналізу' }, { status: 400 });
    }

    await dbConnect();

    // Отримуємо унікальні спеціалізації лікарів з БД
    const doctors = await Doctor.find({}).select('specialization -_id');
    const specializations = [...new Set(doctors.map(d => d.specialization).filter(Boolean))];

    if (specializations.length === 0) {
      return NextResponse.json({ error: 'У системі немає доступних спеціалізацій лікарів' }, { status: 400 });
    }

    const systemPrompt = `Ти досвідчений ШІ-медичний консультант для додатку з реабілітації. 
Твоя мета - проаналізувати профіль пацієнта та його щоденні звіти (якщо є) і порадити ОДНУ спеціалізацію лікаря, до якого йому найкраще звернутися.

Доступні спеціалізації у нашій системі:
${specializations.join(', ')}

Правила:
1. Ти ПОВИНЕН обрати лише одну спеціалізацію зі списку доступних.
2. Поясни свій вибір простою та зрозумілою для пацієнта мовою (до 50 слів).
3. Формат відповіді має бути СУВОРО у форматі JSON без жодного додаткового тексту чи форматування markdown (ніяких блоків \`\`\`json).

Структура JSON:
{
  "analysis": "Твоє коротке пояснення для пацієнта українською мовою.",
  "specialization": "ОДНА спеціалізація зі списку, що найкраще підходить"
}`;

    const userPrompt = `Дані пацієнта:
${JSON.stringify(patientData, null, 2)}

Будь ласка, проаналізуй ці дані і поверни результат у форматі JSON.`;

    const anthropicApiKey = process.env.ANTHROPIC_API_KEY;
    if (!anthropicApiKey) {
      return NextResponse.json({ error: 'Ключ API Anthropic не налаштовано' }, { status: 500 });
    }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': anthropicApiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 500,
        temperature: 0.2,
        system: systemPrompt,
        messages: [
          { role: 'user', content: userPrompt }
        ]
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.warn('Anthropic API недоступне або ключ не має доступу. Використовуємо Mock для демонстрації. Помилка:', errorData);
      
      // MOCK FALLBACK для демонстрації (якщо ключ не працює)
      const diagnosis = patientData.diagnosis?.toLowerCase() || '';
      let recommendedSpec = specializations[0];
      let analysisText = "На основі ваших даних я рекомендую звернутися до цього спеціаліста для комплексної оцінки вашого стану.";
      
      if (diagnosis.includes('спин') || diagnosis.includes('хреб') || diagnosis.includes('остеохондроз')) {
        const specs = specializations.filter(s => s.toLowerCase().includes('фізіотерапевт') || s.toLowerCase().includes('кінезіо'));
        if (specs.length > 0) recommendedSpec = specs[0];
        analysisText = "Враховуючи вашу проблему зі спиною, вам найбільше підійде фахівець з фізичної реабілітації для відновлення рухливості.";
      } else if (diagnosis.includes('травм') || diagnosis.includes('перелом') || diagnosis.includes('суглоб')) {
        const specs = specializations.filter(s => s.toLowerCase().includes('травматолог') || s.toLowerCase().includes('ортопед'));
        if (specs.length > 0) recommendedSpec = specs[0];
        analysisText = "Після травми суглобів найважливіше проконсультуватися з ортопедом-травматологом для правильного зрощення і подальшої розробки.";
      } else {
        const specs = specializations.filter(s => s.toLowerCase().includes('реабілітолог'));
        if (specs.length > 0) recommendedSpec = specs[0];
      }

      return NextResponse.json({
        analysis: analysisText,
        specialization: recommendedSpec
      });
    }

    const data = await response.json();
    const responseText = data.content[0].text;
    
    // Намагаємось розпарсити JSON
    let result;
    try {
      // Іноді Claude може додати текст або бектіки
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      const jsonString = jsonMatch ? jsonMatch[0] : responseText;
      result = JSON.parse(jsonString);
    } catch (e) {
      console.error('Помилка парсингу JSON від Claude:', responseText);
      return NextResponse.json({ error: 'Некоректна відповідь від ШІ' }, { status: 500 });
    }

    return NextResponse.json(result);
  } catch (error) {
    console.error('Помилка в API рекомендації:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
