import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session) {
      return NextResponse.json({ error: 'Не авторизовано' }, { status: 401 });
    }

    const { logs, forDoctor } = await request.json();

    if (!logs || !Array.isArray(logs) || logs.length === 0) {
      return NextResponse.json({ error: 'Немає даних для аналізу' }, { status: 400 });
    }

    const sortedLogs = [...logs].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    const formattedLogs = sortedLogs.map(log => {
      const dateStr = new Date(log.date).toLocaleDateString('uk-UA');
      return `Дата: ${dateStr}, Рівень болю: ${log.painLevel}/10, Емоційний стан: ${log.emotionalState}/10, Нотатки: ${log.notes || 'відсутні'}`;
    }).join('\n');

    const roleText = forDoctor ? 'лікаря (надавай клінічну оцінку)' : 'пацієнта (надавай дружню підтримку та загальні поради)';

    const prompt = `Ти є ШІ-асистентом у системі реабілітації.
Будь ласка, проаналізуй наступні щоденні звіти пацієнта та підготуй аналіз для ${roleText} українською мовою.

Історія звітів пацієнта:
${formattedLogs}

Вимоги до відповіді:
1. Пиши виключно українською мовою.
2. Будь лаконічним (максимум 3-4 короткі абзаци або маркований список).
3. Зроби висновок про динаміку (чи є покращення, погіршення чи стан стабільний).
4. Надай практичні рекомендації (наприклад, щодо навантаження, відпочинку чи потреби звернутися до лікаря).
5. Не використовуй надто складні медичні терміни для пацієнта.`;

    const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;

    if (!apiKey) {
      console.log('GEMINI_API_KEY не знайдено. Використовується евристичний аналіз.');
      
      const painLevels = sortedLogs.map(l => l.painLevel);
      const firstPain = painLevels[0];
      const lastPain = painLevels[painLevels.length - 1];
      
      let trend = 'стабільний';
      let recommendations = '';

      if (lastPain < firstPain) {
        trend = 'позитивна (рівень болю знижується)';
        recommendations = forDoctor 
          ? '* Спостерігається адаптація до навантажень.\n* Рекомендується продовжувати поточну програму та розглянути поступове збільшення кількості повторень на наступному тижні.'
          : '* Ви чудово справляєтесь! Ваш біль поступово зменшується.\n* Продовжуйте виконувати вправи у тому ж темпі, не забуваючи про регулярність.';
      } else if (lastPain > firstPain) {
        trend = 'негативна (рівень болю зріс)';
        recommendations = forDoctor 
          ? '* Пацієнт відчуває зростання больового синдрому.\n* Рекомендується тимчасово зменшити інтенсивність занять або змінити кількість підходів.\n* Бажано провести додатковий огляд пацієнта.'
          : '* Увага! Останнім часом біль трохи посилився.\n* Спробуйте зменшити інтенсивність виконання вправ або зробити перерву.\n* Якщо біль не минає або посилюється, обов\'язково зверніться до свого лікаря.';
      } else {
        trend = 'стабільна без суттєвих змін';
        recommendations = forDoctor 
          ? '* Стан пацієнта без вираженої динаміки.\n* Рекомендується підтримувати поточний рівень навантажень та стежити за правильністю техніки виконання.'
          : '* Ваш стан залишається стабільним.\n* Намагайтеся виконувати вправи плавно, уникаючи різких рухів, та дотримуйтесь рекомендацій лікаря.';
      }

      const mockResponse = `### 📊 Аналіз динаміки стану пацієнта від ШІ (Демо-режим)

**Загальна динаміка:** ${trend}.

**Рекомендації для ${forDoctor ? 'лікаря' : 'Вас'}:**
${recommendations}

*Примітка: Для підключення реального аналізу через модель Gemini, додайте ключ \`GEMINI_API_KEY\` у файл \`.env.local\`.*`;

      return NextResponse.json({ analysis: mockResponse });
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.4,
            maxOutputTokens: 800,
          }
        }),
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      console.error('Помилка Gemini API:', errText);
      throw new Error('Помилка при запиті до Gemini API');
    }

    const data = await response.json();
    const analysisText = data?.candidates?.[0]?.content?.parts?.[0]?.text || 'Не вдалося згенерувати аналіз.';

    return NextResponse.json({ analysis: analysisText });
  } catch (error: any) {
    console.error('Помилка аналізу ШІ:', error);
    return NextResponse.json({ error: 'Помилка під час аналізу даних через ШІ' }, { status: 500 });
  }
}
