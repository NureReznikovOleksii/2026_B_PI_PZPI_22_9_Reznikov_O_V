import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Patient from '@/models/Patient';
import Doctor from '@/models/Doctor';
import { google } from 'googleapis';
import nodemailer from 'nodemailer';
import { Readable } from 'stream';

// Налаштування Google Drive
const GOOGLE_DRIVE_FOLDER_ID = '1oNkDMpfK_QEEIO_LPSH5Zn-IL6Gdue-B';

async function uploadToGoogleDrive(file: File, fileName: string) {
  try {
    // Авторизація через Service Account
    const auth = new google.auth.GoogleAuth({
      keyFile: 'GoogleDriveKey.json', // Шлях від кореня проєкту
      scopes: ['https://www.googleapis.com/auth/drive.file'],
    });

    const drive = google.drive({ version: 'v3', auth });

    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // Перетворюємо Buffer в Readable Stream
    const stream = new Readable();
    stream.push(buffer);
    stream.push(null);

    const fileMetadata = {
      name: fileName,
      parents: [GOOGLE_DRIVE_FOLDER_ID],
    };

    const media = {
      mimeType: file.type,
      body: stream,
    };

    const response = await drive.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: 'id, webViewLink',
    });

    // Робимо файл публічно доступним для читання (щоб адмін міг переглянути по лінку)
    if (response.data.id) {
      await drive.permissions.create({
        fileId: response.data.id,
        requestBody: {
          role: 'reader',
          type: 'anyone',
        },
      });
    }

    return response.data.webViewLink;
  } catch (error) {
    console.error('Помилка завантаження на Google Drive:', error);
    return null;
  }
}

async function sendNotificationEmail(doctorName: string, doctorEmail: string, position: string, certUrl: string) {
  try {
    const transporter = nodemailer.createTransport({
      service: 'gmail', // Або ваш SMTP сервер
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: 'oleksii.reznikov@nure.ua',
      subject: 'Нова заявка на реєстрацію лікаря - RehabTracker',
      html: `
        <h2>Нова заявка від лікаря</h2>
        <p><strong>ПІБ:</strong> ${doctorName}</p>
        <p><strong>Email:</strong> ${doctorEmail}</p>
        <p><strong>Посада:</strong> ${position}</p>
        <p><strong>Сертифікат:</strong> <a href="${certUrl}">Переглянути документ</a></p>
        <br/>
        <p>Для затвердження необхідно змінити статус користувача в системі.</p>
      `,
    };

    await transporter.sendMail(mailOptions);
    console.log('Повідомлення успішно відправлено адміну.');
  } catch (error) {
    console.error('Помилка відправки email (перевірте .env.local):', error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await dbConnect();
    
    const formData = await req.formData();
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    const role = formData.get('role') as 'patient' | 'doctor' | 'admin';

    if (!name || !email || !password || !role) {
      return NextResponse.json({ error: 'Заповніть всі обов\'язкові поля' }, { status: 400 });
    }

    // Перевіряємо чи є такий email
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return NextResponse.json({ error: 'Користувач з таким email вже існує' }, { status: 400 });
    }

    // Хешуємо пароль
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    let newUserStatus: 'pending' | 'active' | 'rejected' | 'allowed' | 'not allowed' = 'allowed'; // Пацієнти дозволені за замовчуванням
    let certificateUrl: string | undefined = undefined;
    let actualRole = role;

    // Автоматично призначаємо права адміна
    if (email === 'doctor@example.com' || email.startsWith('admin_')) {
      actualRole = 'admin';
      newUserStatus = 'allowed';
    } else if (role === 'doctor') {
      newUserStatus = 'not allowed'; // Лікарі чекають апруву
      
      const file = formData.get('certificate') as File;
      const position = formData.get('position') as string;
      const region = formData.get('region') as string;
      const hospitalName = formData.get('hospitalName') as string;

      if (!file || !position || !region || !hospitalName) {
        return NextResponse.json({ error: 'Лікарі повинні вказати посаду, область, заклад та завантажити сертифікат' }, { status: 400 });
      }
    }

    // Створюємо користувача
    const user = await User.create({
      name,
      email,
      passwordHash,
      role: actualRole,
      status: newUserStatus,
    });

    // Створюємо профіль
    if (actualRole === 'patient') {
      await Patient.create({
        userId: user._id,
        diagnosis: 'Не вказано',
      });
    } else if (actualRole === 'doctor' || actualRole === 'admin') {
      const position = formData.get('position') as string;
      const region = formData.get('region') as string;
      const hospitalName = formData.get('hospitalName') as string;
      
      await Doctor.create({
        userId: user._id,
        specialization: 'Не вказано',
        position: position || 'Адміністратор',
        region: region || '',
        hospitalName: hospitalName || '',
        certificateUrl: certificateUrl,
      });
    }

    return NextResponse.json({ 
      success: true, 
      message: role === 'doctor' 
        ? 'Реєстрація успішна. Очікуйте на підтвердження вашого акаунту головним лікарем.' 
        : 'Реєстрація успішна!' 
    });

  } catch (error) {
    console.error('Помилка реєстрації:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера під час реєстрації' }, { status: 500 });
  }
}
