import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import Exercise from '@/models/Exercise';

export async function GET() {
  try {
    await dbConnect();
    const exercises = await Exercise.find({}).sort({ title: 1 });
    return NextResponse.json(exercises);
  } catch (error) {
    console.error('Помилка отримання вправ:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session || session.user.role !== 'doctor') {
      return NextResponse.json({ error: 'Доступ заборонено. Тільки для лікарів.' }, { status: 403 });
    }

    await dbConnect();
    const body = await request.json();
    const { title, description, targetMuscleGroup } = body;

    if (!title || !description) {
      return NextResponse.json({ error: 'Назва та опис вправи є обов’язковими' }, { status: 400 });
    }

    const newExercise = await Exercise.create({
      title,
      description,
      targetMuscleGroup: targetMuscleGroup || 'Загальне',
    });

    return NextResponse.json({ success: true, exercise: newExercise });
  } catch (error) {
    console.error('Помилка створення вправи:', error);
    return NextResponse.json({ error: 'Внутрішня помилка сервера' }, { status: 500 });
  }
}
