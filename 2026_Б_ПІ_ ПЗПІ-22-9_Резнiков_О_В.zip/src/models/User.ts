import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IUser extends Document {
  email: string;
  passwordHash?: string;
  googleId?: string;
  role: 'patient' | 'doctor' | 'admin';
  status: 'pending' | 'active' | 'rejected' | 'allowed' | 'not allowed';
  name: string;
  phone?: string;
  preferences: {
    emailNotif: boolean;
    telegramNotif: boolean;
    telegramChatId?: string;
  };
  createdAt: Date;
  updatedAt: Date;
}

const UserSchema: Schema = new Schema(
  {
    email: { type: String, required: true, unique: true },
    passwordHash: { type: String },
    googleId: { type: String },
    role: { type: String, enum: ['patient', 'doctor', 'admin'], required: true },
    status: { type: String, enum: ['pending', 'active', 'rejected', 'allowed', 'not allowed'], default: 'active' },
    name: { type: String, required: true },
    phone: { type: String },
    preferences: {
      emailNotif: { type: Boolean, default: true },
      telegramNotif: { type: Boolean, default: false },
      telegramChatId: { type: String },
    },
  },
  { timestamps: true }
);

const User: Model<IUser> = mongoose.models.User || mongoose.model<IUser>('User', UserSchema);

export default User;
