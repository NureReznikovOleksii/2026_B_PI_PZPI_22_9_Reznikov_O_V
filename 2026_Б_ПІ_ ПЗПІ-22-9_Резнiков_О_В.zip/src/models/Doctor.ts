import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IFeedback {
  text: string;
  rating?: number;
  createdAt: Date;
}

export interface IDoctor extends Document {
  userId: mongoose.Types.ObjectId;
  specialization: string;
  position?: string;
  region?: string;
  hospitalName?: string;
  certificateUrl?: string;
  feedbacks?: IFeedback[];
  createdAt: Date;
  updatedAt: Date;
}

const DoctorSchema: Schema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    specialization: { type: String, required: true },
    position: { type: String },
    region: { type: String },
    hospitalName: { type: String },
    certificateUrl: { type: String },
    feedbacks: [
      {
        text: { type: String, required: true },
        rating: { type: Number },
        createdAt: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

const Doctor: Model<IDoctor> = mongoose.models.Doctor || mongoose.model<IDoctor>('Doctor', DoctorSchema);

export default Doctor;
