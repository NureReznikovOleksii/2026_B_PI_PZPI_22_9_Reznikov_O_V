import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IProgramMedication {
  name: string;
  dosage: string;     // e.g. "1 таблетка" or "100 мг"
  frequency: string;  // e.g. "двічі на день" or "вранці"
  duration: string;   // e.g. "7 днів"
}

export interface IProgram extends Document {
  title: string;
  description: string;
  creatorDoctorId: mongoose.Types.ObjectId;
  medications?: IProgramMedication[];
  createdAt: Date;
  updatedAt: Date;
}

const ProgramSchema: Schema = new Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    creatorDoctorId: { type: Schema.Types.ObjectId, ref: 'User', required: true }, // Doctor who created this template
    medications: [
      {
        name: { type: String, required: true },
        dosage: { type: String, required: true },
        frequency: { type: String, required: true },
        duration: { type: String, required: true },
      }
    ],
  },
  { timestamps: true }
);

const Program: Model<IProgram> = mongoose.models.Program || mongoose.model<IProgram>('Program', ProgramSchema);

export default Program;
