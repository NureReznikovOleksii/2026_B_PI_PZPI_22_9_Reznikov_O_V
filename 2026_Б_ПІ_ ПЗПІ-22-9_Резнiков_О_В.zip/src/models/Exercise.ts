import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IExercise extends Document {
  title: string;
  description: string;
  videoUrl?: string;
  imageUrl?: string;
  targetMuscleGroup: string;
  createdAt: Date;
  updatedAt: Date;
}

const ExerciseSchema: Schema = new Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    videoUrl: { type: String },
    imageUrl: { type: String },
    targetMuscleGroup: { type: String, required: true },
  },
  { timestamps: true }
);

const Exercise: Model<IExercise> = mongoose.models.Exercise || mongoose.model<IExercise>('Exercise', ExerciseSchema);

export default Exercise;
