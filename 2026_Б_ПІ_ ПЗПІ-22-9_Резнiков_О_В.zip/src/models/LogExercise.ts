import mongoose, { Schema, Document, Model } from 'mongoose';

export interface ILogExercise extends Document {
  logId: mongoose.Types.ObjectId;
  exerciseId: mongoose.Types.ObjectId;
  completedSets: number;
  completedReps: number;
  actualDurationSeconds?: number;
  painDuringExercise?: number; // 1-10
  createdAt: Date;
  updatedAt: Date;
}

const LogExerciseSchema: Schema = new Schema(
  {
    logId: { type: Schema.Types.ObjectId, ref: 'DailyLog', required: true },
    exerciseId: { type: Schema.Types.ObjectId, ref: 'Exercise', required: true },
    completedSets: { type: Number, required: true },
    completedReps: { type: Number, required: true },
    actualDurationSeconds: { type: Number },
    painDuringExercise: { type: Number, min: 1, max: 10 },
  },
  { timestamps: true }
);

const LogExercise: Model<ILogExercise> = mongoose.models.LogExercise || mongoose.model<ILogExercise>('LogExercise', LogExerciseSchema);

export default LogExercise;
