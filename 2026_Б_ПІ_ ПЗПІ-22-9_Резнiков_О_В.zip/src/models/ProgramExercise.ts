import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IProgramExercise extends Document {
  programId: mongoose.Types.ObjectId;
  exerciseId: mongoose.Types.ObjectId;
  sets: number;
  reps: number;
  durationSeconds?: number;
  createdAt: Date;
  updatedAt: Date;
}

const ProgramExerciseSchema: Schema = new Schema(
  {
    programId: { type: Schema.Types.ObjectId, ref: 'Program', required: true },
    exerciseId: { type: Schema.Types.ObjectId, ref: 'Exercise', required: true },
    sets: { type: Number, required: true, default: 3 },
    reps: { type: Number, required: true, default: 10 },
    durationSeconds: { type: Number },
  },
  { timestamps: true }
);

const ProgramExercise: Model<IProgramExercise> = mongoose.models.ProgramExercise || mongoose.model<IProgramExercise>('ProgramExercise', ProgramExerciseSchema);

export default ProgramExercise;
