import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IPatientAssignment extends Document {
  patientId: mongoose.Types.ObjectId;
  programId: mongoose.Types.ObjectId;
  assignedBy: mongoose.Types.ObjectId;
  startDate: Date;
  endDate?: Date;
  status: 'active' | 'completed' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

const PatientAssignmentSchema: Schema = new Schema(
  {
    patientId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    programId: { type: Schema.Types.ObjectId, ref: 'Program', required: true },
    assignedBy: { type: Schema.Types.ObjectId, ref: 'User', required: true }, // Doctor who assigned it
    startDate: { type: Date, required: true, default: Date.now },
    endDate: { type: Date },
    status: { type: String, enum: ['active', 'completed', 'cancelled'], default: 'active' },
  },
  { timestamps: true }
);

const PatientAssignment: Model<IPatientAssignment> = mongoose.models.PatientAssignment || mongoose.model<IPatientAssignment>('PatientAssignment', PatientAssignmentSchema);

export default PatientAssignment;
