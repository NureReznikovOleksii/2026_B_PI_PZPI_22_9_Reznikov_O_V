import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IPatient extends Document {
  userId: mongoose.Types.ObjectId;
  doctorId?: mongoose.Types.ObjectId;
  pendingDoctorId?: mongoose.Types.ObjectId;
  doctorRequestStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  diagnosis: string;
  startDate: Date;
  medicalHistory?: string;
  region?: string;
  hospitalName?: string;
  hasCompletedOnboarding: boolean;
  age?: number;
  gender?: string;
  primaryProblem?: string;
  initialPainLevel?: number;
  dailyLimitations?: string;
  surgeryHistory?: string;
  rehabGoals?: string;
  createdAt: Date;
  updatedAt: Date;
}

const PatientSchema: Schema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    doctorId: { type: Schema.Types.ObjectId, ref: 'User' }, // Вказує на лікаря (User з role='doctor')
    pendingDoctorId: { type: Schema.Types.ObjectId, ref: 'User' }, // Лікар, до якого подано заявку
    doctorRequestStatus: { 
      type: String, 
      enum: ['none', 'pending', 'approved', 'rejected'], 
      default: 'none' 
    },
    diagnosis: { type: String, required: true },
    startDate: { type: Date, default: Date.now },
    medicalHistory: { type: String },
    region: { type: String },
    hospitalName: { type: String },
    hasCompletedOnboarding: { type: Boolean, default: false },
    age: { type: Number },
    gender: { type: String, enum: ['Чоловіча', 'Жіноча', 'Інше'] },
    primaryProblem: { type: String },
    initialPainLevel: { type: Number, min: 1, max: 10 },
    dailyLimitations: { type: String },
    surgeryHistory: { type: String },
    rehabGoals: { type: String },
  },
  { timestamps: true }
);

const Patient: Model<IPatient> = mongoose.models.Patient || mongoose.model<IPatient>('Patient', PatientSchema);

export default Patient;
