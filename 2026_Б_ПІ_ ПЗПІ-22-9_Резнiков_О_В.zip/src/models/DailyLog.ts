import mongoose, { Schema, Document, Model } from 'mongoose';

export interface IDailyLog extends Document {
  patientId: mongoose.Types.ObjectId;
  assignmentId: mongoose.Types.ObjectId;
  date: Date;
  painLevel: number; // 1-10
  emotionalState: number; // 1-10 or 1-5
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

const DailyLogSchema: Schema = new Schema(
  {
    patientId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    assignmentId: { type: Schema.Types.ObjectId, ref: 'PatientAssignment', required: true },
    date: { type: Date, required: true, default: Date.now },
    painLevel: { type: Number, required: true, min: 1, max: 10 },
    emotionalState: { type: Number, required: true, min: 1, max: 10 },
    notes: { type: String },
  },
  { timestamps: true }
);

const DailyLog: Model<IDailyLog> = mongoose.models.DailyLog || mongoose.model<IDailyLog>('DailyLog', DailyLogSchema);

export default DailyLog;
