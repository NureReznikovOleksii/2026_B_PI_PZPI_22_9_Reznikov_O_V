"use client";

import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface PatientChartProps {
  logs: any[];
}

export default function PatientChart({ logs }: PatientChartProps) {
  if (!logs || logs.length === 0) {
    return <div className="p-4 text-center text-slate-500">Немає даних для побудови графіка</div>;
  }

  // Сортуємо по даті (від найстарішого до найновішого)
  const sortedLogs = [...logs].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const labels = sortedLogs.map(log => new Date(log.date).toLocaleDateString('uk-UA', { month: 'short', day: 'numeric' }));
  const painData = sortedLogs.map(log => log.painLevel);
  const emotionData = sortedLogs.map(log => log.emotionalState);

  const data = {
    labels,
    datasets: [
      {
        label: 'Рівень болю',
        data: painData,
        borderColor: 'rgb(244, 63, 94)', // rose-500
        backgroundColor: 'rgba(244, 63, 94, 0.5)',
        tension: 0.3,
      },
      {
        label: 'Емоційний стан',
        data: emotionData,
        borderColor: 'rgb(59, 130, 246)', // blue-500
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
        tension: 0.3,
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Динаміка стану пацієнта за останні дні',
      },
    },
    scales: {
      y: {
        min: 0,
        max: 10,
      }
    }
  };

  return <Line options={options} data={data} />;
}
