const mongoose = require('mongoose');
const MONGODB_URI = "mongodb+srv://db_user:f0xc5Egr9AsjRyJP@main.tmodwhs.mongodb.net/main";

async function fix() {
  await mongoose.connect(MONGODB_URI);
  const res = await mongoose.connection.db.collection('users').updateMany(
    { password: { $exists: true } },
    { $rename: { 'password': 'passwordHash' } }
  );
  console.log('Updated:', res.modifiedCount);
  process.exit(0);
}

fix();
