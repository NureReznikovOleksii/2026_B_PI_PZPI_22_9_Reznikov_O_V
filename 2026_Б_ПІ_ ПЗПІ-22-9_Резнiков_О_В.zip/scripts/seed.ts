import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import * as dotenv from 'dotenv';
import path from 'path';

// Завантаження змінних середовища з .env.local
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

import User from '../src/models/User';
import Patient from '../src/models/Patient';
import Doctor from '../src/models/Doctor';
import Exercise from '../src/models/Exercise';
import Program from '../src/models/Program';
import ProgramExercise from '../src/models/ProgramExercise';
import PatientAssignment from '../src/models/PatientAssignment';
import DailyLog from '../src/models/DailyLog';
import LogExercise from '../src/models/LogExercise';

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  throw new Error('Please define the MONGODB_URI environment variable inside .env.local');
}

async function seed() {
  try {
    console.log('Підключення до бази даних...');
    await mongoose.connect(MONGODB_URI as string);
    console.log('Успішне підключення!');

    console.log('Очищення бази даних...');
    await User.deleteMany({});
    await Patient.deleteMany({});
    await Doctor.deleteMany({});
    await Exercise.deleteMany({});
    await Program.deleteMany({});
    await ProgramExercise.deleteMany({});
    await PatientAssignment.deleteMany({});
    await DailyLog.deleteMany({});
    await LogExercise.deleteMany({});

    console.log('Створення користувачів...');
    const passwordHash = await bcrypt.hash('password123', 10);

    const doctorUser = await User.create({
      email: 'doctor@example.com',
      passwordHash,
      role: 'doctor',
      name: 'Dr. Іван Олександрович',
    });

    const patientUser = await User.create({
      email: 'patient@example.com',
      passwordHash,
      role: 'patient',
      name: 'Олексій Коваленко',
    });

    console.log('Створення профілів лікаря та пацієнта...');
    await Doctor.create({
      userId: doctorUser._id,
      specialization: 'Ортопед-травматолог',
      hospitalName: 'Київська Міська Лікарня',
    });

    await Patient.create({
      userId: patientUser._id,
      doctorId: doctorUser._id,
      diagnosis: 'Реабілітація після перелому колінного суглоба',
    });

    console.log('Створення вправ...');
    const exercises = await Exercise.insertMany([
      { title: 'Згинання коліна лежачи', description: 'Повільно згинайте ногу в коліні, підтягуючи п’яту до сідниць.', targetMuscleGroup: 'Ноги' },
      { title: 'Підйом прямої ноги', description: 'Лежачи на спині, піднімайте випрямлену ногу на 45 градусів.', targetMuscleGroup: 'Ноги' },
      { title: 'Обертання стопою', description: 'Плавно обертайте стопою за та проти годинникової стрілки.', targetMuscleGroup: 'Гомілкостоп' },
    ]);

    console.log('Створення програми...');
    const program = await Program.create({
      title: 'Відновлення коліна (Етап 1)',
      description: 'Базові вправи для відновлення рухливості колінного суглоба.',
      creatorDoctorId: doctorUser._id,
    });

    console.log('Додавання вправ до програми...');
    for (const ex of exercises) {
      await ProgramExercise.create({
        programId: program._id,
        exerciseId: ex._id,
        sets: 3,
        reps: 10,
      });
    }

    console.log('Призначення програми пацієнту...');
    const assignment = await PatientAssignment.create({
      patientId: patientUser._id,
      programId: program._id,
      assignedBy: doctorUser._id,
      status: 'active',
    });

    console.log('Створення щоденників (Daily Logs) за останні 7 днів...');
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const logDate = new Date(today);
      logDate.setDate(today.getDate() - i);

      // Випадкові дані
      const painLevel = Math.floor(Math.random() * 4) + 2; // Біль від 2 до 5
      const emotionalState = Math.floor(Math.random() * 3) + 7; // Настрій від 7 до 9

      const dailyLog = await DailyLog.create({
        patientId: patientUser._id,
        assignmentId: assignment._id,
        date: logDate,
        painLevel,
        emotionalState,
        notes: i === 0 ? 'Сьогодні було легше виконувати вправи.' : '',
      });

      for (const ex of exercises) {
        await LogExercise.create({
          logId: dailyLog._id,
          exerciseId: ex._id,
          completedSets: 3,
          completedReps: Math.floor(Math.random() * 3) + 8, // Від 8 до 10
          painDuringExercise: painLevel,
        });
      }
    }

    console.log('✅ Базу даних успішно заповнено тестовими даними!');
    process.exit(0);
  } catch (error) {
    console.error('Помилка:', error);
    process.exit(1);
  }
}

seed();
