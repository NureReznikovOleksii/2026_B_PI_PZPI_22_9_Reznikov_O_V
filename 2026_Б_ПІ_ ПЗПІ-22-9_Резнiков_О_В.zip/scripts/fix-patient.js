const mongoose = require('mongoose');
const MONGODB_URI = "mongodb+srv://db_user:f0xc5Egr9AsjRyJP@main.tmodwhs.mongodb.net/main";

async function fix() {
  await mongoose.connect(MONGODB_URI);
  const res = await mongoose.connection.db.collection('patients').updateMany(
    { doctorRequestStatus: 'pending', doctorId: { $ne: null } },
    { $set: { doctorId: null } }
  );
  console.log('Fixed patients:', res.modifiedCount);
  process.exit(0);
}

fix();
