const apiKey = "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";

async function test(model) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: model,
      max_tokens: 10,
      messages: [{ role: 'user', content: 'Hi' }]
    })
  });
  console.log(model, res.status, await res.text());
}

async function run() {
  await test('claude-3-haiku-20240307');
  await test('claude-3-5-sonnet-20241022');
  await test('claude-3-5-haiku-20241022');
}
run();
