describe('Diploma E2E Flow with Screenshots', () => {
  const uniqueId = Date.now();
  const adminEmail = `admin_${uniqueId}@test.com`;
  const doctorEmail = `doc_${uniqueId}@test.com`;
  const patientEmail = `pat_${uniqueId}@test.com`;
  const doctorName = `Д-р Іван Вертебролог ${uniqueId}`;
  const patientName = `Олександр Травмований ${uniqueId}`;
  const password = 'password123';

  before(() => {
    cy.clearCookies();
    cy.clearLocalStorage();
  });

  it('Registers admin, doctor, approves doctor, registers patient, runs AI, sends request, and creates course', () => {
    // 0. Реєстрація адміна
    cy.visit('/register');
    cy.wait(1500); // Чекаємо Hydration
    cy.contains('button', 'Пацієнт').click(); // Реєструємо як пацієнта, але бекенд зробить адміном через префікс admin_
    cy.wait(500);
    cy.get('input[placeholder="Олексій Іванов"]').type('Головний Адміністратор');
    cy.get('input[type="email"]').type(adminEmail);
    cy.get('input[type="password"]').type(password);
    cy.get('button[type="submit"]').click();
    cy.url({ timeout: 10000 }).should('include', '/login');
    cy.wait(1000);

    // 1. Реєстрація лікаря
    cy.visit('/register');
    cy.wait(1500);
    cy.contains('button', 'Лікар').click();
    cy.wait(500);
    cy.get('input[placeholder="Олексій Іванов"]').type(doctorName);
    cy.get('input[type="email"]').type(doctorEmail);
    cy.get('input[type="password"]').type(password);
    cy.get('input[placeholder="Хірург-реабілітолог, Голов Врач..."]').type('Фізіотерапевт');
    
    // Нові поля для лікаря (Область та Лікарня)
    cy.get('select').eq(0).select('Київська область');
    cy.wait(500); // Чекаємо підвантаження лікарень
    cy.get('select').eq(1).select('Київська обласна клінічна лікарня');

    cy.get('input[type="file"]').selectFile({
      contents: Cypress.Buffer.from('file contents'),
      fileName: 'certificate.pdf',
      lastModified: Date.now(),
    }, { force: true });
    
    cy.get('button[type="submit"]').click();
    cy.url({ timeout: 10000 }).should('include', '/login');
    cy.wait(1000);

    // 2. Логін адміном та апрув лікаря
    cy.visit('/login');
    cy.get('input[type="email"]').clear().type(adminEmail);
    cy.get('input[type="password"]').clear().type(password);
    cy.get('button[type="submit"]').click();
    cy.wait(2000);
    
    // Перевіряємо що ми в адмінці і йдемо на Заявки
    cy.url().should('include', '/admin');
    cy.contains('button', 'Заявки').click({ force: true });
    cy.wait(1000);
    
    // Знаходимо лікаря і підтверджуємо
    cy.contains(doctorName).parents('.bg-white').first().within(() => {
      cy.contains('button', 'Підтвердити').click({ force: true });
    });
    cy.wait(3000);
    
    // Логаут адміна
    cy.contains('Вийти').click({ force: true });
    cy.wait(1000);

    // 3. Реєстрація пацієнта
    cy.visit('/register');
    cy.wait(1500);
    cy.contains('button', 'Пацієнт').click();
    cy.wait(500);
    cy.get('input[placeholder="Олексій Іванов"]').type(patientName);
    cy.get('input[type="email"]').type(patientEmail);
    cy.get('input[type="password"]').type(password);
    cy.get('button[type="submit"]').click();
    cy.url({ timeout: 10000 }).should('include', '/login');
    cy.wait(1000);

    // 4. Логін пацієнтом
    cy.get('input[type="email"]').clear().type(patientEmail);
    cy.get('input[type="password"]').clear().type(password);
    cy.get('button[type="submit"]').click();

    // 5. Онбордінг
    cy.wait(2000);
    cy.url().then((url) => {
      if (url.includes('onboarding')) {
        cy.get('input[placeholder*="35"]').type('30');
        cy.get('select').select('Чоловіча');
        cy.get('input[placeholder*="травма коліна"]').type('Біль у попереку та спині');
        cy.get('textarea').eq(0).type('Важко сидіти');
        cy.get('textarea').eq(1).type('Без операцій');
        cy.get('textarea').eq(2).type('Відновлення повної рухливості');
        cy.get('button[type="submit"]').click();
        cy.wait(2000);
      }
    });

    // Очікуємо завантаження дашборду
    cy.contains('button', 'Профіль', { timeout: 10000 }).click({ force: true });
    cy.wait(500);
    cy.contains('button', 'Медичний заклад та лікар', { timeout: 10000 }).click({ force: true });
    cy.wait(1000);
    cy.screenshot('1_patient_profile');

    // 6. ШІ Аналіз
    cy.contains('button', 'Проаналізувати стан').click({ force: true });
    cy.wait(4000);
    cy.screenshot('2_ai_analysis');

    // 6.5 Вибір локації (щоб з'явився список лікарів)
    cy.get('select').eq(0).select('Київська область');
    cy.wait(500);
    cy.get('select').eq(1).select('Київська обласна клінічна лікарня');
    cy.wait(1000);

    // 7. Подача заявки лікарю
    cy.contains(doctorName, { timeout: 15000 }).parents('.bg-white').first().within(() => {
      cy.contains('button', 'Надіслати заявку').click({ force: true });
    });
    cy.wait(1000);
    cy.screenshot('3_application_sent');

    // 8. Логаут пацієнта
    cy.contains('Вийти').click({ force: true });
    cy.wait(1000);

    // 9. Логін лікарем
    cy.visit('/login');
    cy.get('input[type="email"]').clear().type(doctorEmail);
    cy.get('input[type="password"]').clear().type(password);
    cy.get('button[type="submit"]').click();
    cy.wait(2000);
    cy.screenshot('4_doctor_dashboard');

    // 10. Прийняття заявки
    cy.contains('button', 'Заявки').click({ force: true });
    cy.wait(1000);
    cy.contains(patientName).should('exist');
    cy.contains('Прийняти').click({ force: true });
    cy.wait(1000);
    cy.screenshot('5_doctor_accepted_patient');

    // 11. Створення курсу
    cy.contains('button', 'Конструктор програм').click({ force: true });
    cy.wait(1000);
    cy.contains('button', 'Створити нову програму').click({ force: true });
    
    cy.get('input[placeholder*="напр., Етап 1"]').type('Курс відновлення спини');
    cy.get('textarea[placeholder*="Вкажіть мету програми"]').type("Щоденні вправи для укріплення м'язів кора");
    
    // Додаємо хоча б одну вправу
    cy.contains('button', 'Додати').first().click({ force: true });
    
    cy.contains('button', 'Зберегти шаблон програми').click({ force: true });
    cy.wait(2000);
    
    // 12. Призначення курсу пацієнту
    cy.contains('button', 'Пацієнти').click({ force: true });
    cy.wait(1000);
    cy.contains(patientName).click({ force: true });
    cy.wait(1000);
    
    cy.contains('button', 'Призначити').click({ force: true });
    cy.wait(1000);
    
    cy.get('select').select('Курс відновлення спини');
    cy.contains('button', 'Призначити програму').click({ force: true });
    cy.wait(2000);
    
    cy.screenshot('6_course_created');
  });
});
