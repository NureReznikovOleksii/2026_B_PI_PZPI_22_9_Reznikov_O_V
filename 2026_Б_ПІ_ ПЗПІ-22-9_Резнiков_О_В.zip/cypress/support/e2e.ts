// Import commands.js using ES2015 syntax:
// import './commands'

// Alternatively you can use CommonJS syntax:
// require('./commands')

// Скриваємо помилки від React/Next.js, які не впливають на сам тест
Cypress.on('uncaught:exception', (err, runnable) => {
  // повертаємо false, щоб запобігти падінню Cypress
  return false;
});
